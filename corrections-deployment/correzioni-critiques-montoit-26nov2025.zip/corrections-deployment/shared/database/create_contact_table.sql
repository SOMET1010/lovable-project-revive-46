-- Script de création de la table contact_submissions pour MONTOIT-STABLE
-- Ce script doit être exécuté dans Supabase SQL Editor ou via les migrations

-- 1. Création de la table pour stocker les soumissions de contact
CREATE TABLE IF NOT EXISTS contact_submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Informations de base du contact
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    
    -- Métadonnées temporelles
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Statut de traitement
    status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'read', 'replied', 'archived')),
    
    -- Informations techniques (optionnel)
    ip_address INET,
    user_agent TEXT,
    
    -- Réponse de l'équipe (pour le suivi)
    admin_response TEXT,
    responded_at TIMESTAMP WITH TIME ZONE,
    responded_by UUID REFERENCES auth.users(id),
    
    -- Tags pour la catégorisation
    tags TEXT[] DEFAULT '{}',
    
    -- Priorité
    priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    
    -- Informations supplémentaires
    phone TEXT,
    company TEXT,
    
    -- Métadonnées de tracking
    utm_source TEXT,
    utm_medium TEXT,
    utm_campaign TEXT,
    referrer TEXT,
    
    -- Horodatage de création/mise à jour
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Index pour améliorer les performances des requêtes
CREATE INDEX IF NOT EXISTS idx_contact_submissions_status ON contact_submissions(status);
CREATE INDEX IF NOT EXISTS idx_contact_submissions_submitted_at ON contact_submissions(submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_contact_submissions_email ON contact_submissions(email);
CREATE INDEX IF NOT EXISTS idx_contact_submissions_priority ON contact_submissions(priority);

-- 3. Row Level Security (RLS) - Permettre l'insertion pour tous
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;

-- Politique pour permettre à tous les utilisateurs de soumettre des messages
CREATE POLICY "Allow public submissions" ON contact_submissions
    FOR INSERT 
    TO public
    WITH CHECK (true);

-- Politique pour permettre aux utilisateurs authentifiés de lire les messages
CREATE POLICY "Allow authenticated users to read submissions" ON contact_submissions
    FOR SELECT 
    TO authenticated
    USING (true);

-- Politique pour permettre aux utilisateurs authentifiés de mettre à jour les messages
CREATE POLICY "Allow authenticated users to update submissions" ON contact_submissions
    FOR UPDATE 
    TO authenticated
    USING (true);

-- 4. Fonction pour mettre à jour automatiquement le updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger pour mettre à jour updated_at automatiquement
CREATE TRIGGER update_contact_submissions_updated_at 
    BEFORE UPDATE ON contact_submissions 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- 5. Vue pour faciliter les statistiques
CREATE OR REPLACE VIEW contact_submissions_stats AS
SELECT 
    status,
    COUNT(*) as count,
    DATE_TRUNC('day', submitted_at) as date,
    priority,
    subject
FROM contact_submissions
GROUP BY status, DATE_TRUNC('day', submitted_at), priority, subject
ORDER BY date DESC, count DESC;

-- 6. Fonction pour obtenir les statistiques globales
CREATE OR REPLACE FUNCTION get_contact_stats(
    days_back INTEGER DEFAULT 30
)
RETURNS TABLE (
    total_submissions BIGINT,
    new_submissions BIGINT,
    replied_submissions BIGINT,
    avg_response_time INTERVAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*)::BIGINT as total_submissions,
        COUNT(*) FILTER (WHERE status = 'new')::BIGINT as new_submissions,
        COUNT(*) FILTER (WHERE status = 'replied')::BIGINT as replied_submissions,
        AVG(responded_at - submitted_at) as avg_response_time
    FROM contact_submissions
    WHERE submitted_at >= NOW() - INTERVAL '1 day' * days_back;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. Trigger pour notifications (optionnel - nécessite pg_notify)
CREATE OR REPLACE FUNCTION notify_new_contact_submission()
RETURNS TRIGGER AS $$
BEGIN
    -- Envoyer une notification via pg_notify
    PERFORM pg_notify('new_contact_submission', NEW.id::TEXT);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_new_contact_submission
    AFTER INSERT ON contact_submissions
    FOR EACH ROW
    EXECUTE FUNCTION notify_new_contact_submission();

-- 8. Insertion de données de test (optionnel)
-- DELETE FROM contact_submissions; -- Décommenter pour effacer les données existantes
/*
INSERT INTO contact_submissions (name, email, subject, message, status) VALUES
('Jean Dupont', 'jean.dupont@email.com', 'support', 'Bonjour, j''ai besoin d''aide avec mon compte.', 'new'),
('Marie Kouame', 'marie.kouame@email.com', 'partnership', 'Intéressée par un partenariat commercial.', 'read'),
('Paul Yao', 'paul.yao@email.com', 'other', 'Question générale sur vos services.', 'replied');
*/

-- 9. Commentaires pour documenter la structure
COMMENT ON TABLE contact_submissions IS 'Table pour stocker les soumissions de formulaire de contact';
COMMENT ON COLUMN contact_submissions.name IS 'Nom complet de l''expéditeur';
COMMENT ON COLUMN contact_submissions.email IS 'Adresse email de l''expéditeur';
COMMENT ON COLUMN contact_submissions.subject IS 'Sujet de la demande';
COMMENT ON COLUMN contact_submissions.message IS 'Contenu du message';
COMMENT ON COLUMN contact_submissions.status IS 'Statut de traitement: new, read, replied, archived';
COMMENT ON COLUMN contact_submissions.priority IS 'Priorité: low, normal, high, urgent';
COMMENT ON COLUMN contact_submissions.admin_response IS 'Réponse apportée par l''équipe';
COMMENT ON COLUMN contact_submissions.tags IS 'Tags pour catégoriser les demandes';

-- 10. Validation des données avec des contraintes
ALTER TABLE contact_submissions 
ADD CONSTRAINT check_name_length CHECK (char_length(name) >= 2 AND char_length(name) <= 100),
ADD CONSTRAINT check_message_length CHECK (char_length(message) >= 10 AND char_length(message) <= 2000),
ADD CONSTRAINT check_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');

-- Fin du script