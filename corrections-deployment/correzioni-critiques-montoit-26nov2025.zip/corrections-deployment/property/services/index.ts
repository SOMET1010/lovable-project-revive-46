export { propertyService, default as PropertyService } from './propertyService';
export type { PropertyData, PropertyFormErrors } from './propertyService';