-- ========================================
-- SCRIPT DE RÉPARATION SUPABASE - MONTOIT
-- Correction Erreur HTTP 500 "Database error saving new user"
-- Date: 26 novembre 2025
-- Projet: tayhmawgohcocfnfhaku
-- ========================================

-- 🚨 ATTENTION: Exécuter ce script avec les permissions service_role

-- ========================================
-- PHASE 1: CRÉATION TABLE PROFILES
-- ========================================

-- Créer la table profiles avec toutes les colonnes nécessaires
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
    full_name TEXT,
    phone TEXT,
    email TEXT,
    verification_type TEXT CHECK (verification_type IN ('email', 'sms', 'whatsapp')),
    phone_verified BOOLEAN DEFAULT FALSE,
    email_verified BOOLEAN DEFAULT FALSE,
    whatsapp_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Colonnes additionnelles pour le marché ivoirien
    country_code TEXT DEFAULT 'CI',
    city TEXT,
    district TEXT,
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

-- Commentaires pour documenter la table
COMMENT ON TABLE public.profiles IS 'Profils utilisateurs étendus pour MONTOIT';
COMMENT ON COLUMN public.profiles.verification_type IS 'Type de vérification utilisé lors de l inscription';
COMMENT ON COLUMN public.profiles.country_code IS 'Code pays, par défaut CI pour Côte d Ivoire';

-- ========================================
-- PHASE 2: CONFIGURATION ROW LEVEL SECURITY (RLS)
-- ========================================

-- Activer RLS sur la table profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Supprimer les politiques existantes si elles existent (pour éviter les conflits)
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can delete own profile" ON public.profiles;

-- Créer les politiques RLS pour sécuriser les accès
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can delete own profile" ON public.profiles
    FOR DELETE USING (auth.uid() = id);

-- Politique pour permettre la lecture publique du nom (pour les propriétaires de biens)
CREATE POLICY "Public can view basic profile info" ON public.profiles
    FOR SELECT USING (true)
    WITH CHECK (true);

-- ========================================
-- PHASE 3: INDEX POUR OPTIMISATION
-- ========================================

-- Supprimer les index existants pour éviter les conflits
DROP INDEX IF EXISTS idx_profiles_id;
DROP INDEX IF EXISTS idx_profiles_phone;
DROP INDEX IF EXISTS idx_profiles_email;
DROP INDEX IF EXISTS idx_profiles_verification_type;
DROP INDEX IF EXISTS idx_profiles_verification;
DROP INDEX IF EXISTS idx_profiles_city;
DROP INDEX IF EXISTS idx_profiles_is_active;

-- Créer les index pour optimiser les performances
CREATE INDEX idx_profiles_id ON public.profiles(id);
CREATE INDEX idx_profiles_phone ON public.profiles(phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_profiles_email ON public.profiles(email) WHERE email IS NOT NULL;
CREATE INDEX idx_profiles_verification_type ON public.profiles(verification_type) WHERE verification_type IS NOT NULL;
CREATE INDEX idx_profiles_city ON public.profiles(city) WHERE city IS NOT NULL;
CREATE INDEX idx_profiles_is_active ON public.profiles(is_active) WHERE is_active = TRUE;

-- Index composite pour les recherches fréquentes
CREATE INDEX idx_profiles_active_verified ON public.profiles(is_active, verification_type) 
    WHERE is_active = TRUE;

-- ========================================
-- PHASE 4: FONCTIONS ET TRIGGERS D'AUTHENTIFICATION
-- ========================================

-- Supprimer les fonctions existantes si elles existent
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS update_updated_at_column();
DROP FUNCTION IF EXISTS fix_existing_users();

-- Fonction pour créer automatiquement un profil lors de l'inscription
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    user_email TEXT;
    user_phone TEXT;
BEGIN
    -- Extraire les métadonnées
    user_email := COALESCE(NEW.email, NEW.raw_user_meta_data->>'email', '');
    user_phone := COALESCE(NEW.raw_user_meta_data->>'phone', '');
    
    -- Créer le profil avec gestion d'erreur robuste
    INSERT INTO public.profiles (
        id, 
        full_name, 
        email,
        phone,
        verification_type,
        created_at, 
        updated_at
    )
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        user_email,
        user_phone,
        CASE 
            WHEN user_phone IS NOT NULL AND user_phone != '' THEN 'phone'
            ELSE 'email'
        END,
        NOW(),
        NOW()
    );
    
    RETURN NEW;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Le profil existe déjà, ne pas faire échouer l'inscription
        RAISE NOTICE 'Profil existant ignoré pour utilisateur %', NEW.id;
        RETURN NEW;
        
    WHEN OTHERS THEN
        -- Log l'erreur mais ne pas faire échouer l'inscription
        RAISE WARNING 'Erreur lors de la création du profil pour l''utilisateur %: %', 
                      NEW.id, SQLERRM;
        RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fonction pour mise à jour automatique du timestamp updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Fonction pour corriger les utilisateurs existants sans profil
CREATE OR REPLACE FUNCTION fix_existing_users()
RETURNS TABLE(
    users_fixed INTEGER
) AS $$
DECLARE
    fixed_count INTEGER := 0;
BEGIN
    INSERT INTO public.profiles (id, full_name, email, phone, verification_type, created_at, updated_at)
    SELECT 
        u.id,
        COALESCE(u.raw_user_meta_data->>'full_name', ''),
        COALESCE(u.email, u.raw_user_meta_data->>'email', ''),
        COALESCE(u.raw_user_meta_data->>'phone', ''),
        CASE 
            WHEN (u.raw_user_meta_data->>'phone') IS NOT NULL AND (u.raw_user_meta_data->>'phone') != '' THEN 'phone'
            ELSE 'email'
        END,
        u.created_at,
        NOW()
    FROM auth.users u
    WHERE NOT EXISTS (
        SELECT 1 FROM public.profiles p WHERE p.id = u.id
    );
    
    GET DIAGNOSTICS fixed_count = ROW_COUNT;
    
    RETURN QUERY SELECT fixed_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ========================================
-- PHASE 5: CRÉATION DES TRIGGERS
-- ========================================

-- Supprimer les triggers existants
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;

-- Trigger pour créer automatiquement le profil lors de l'inscription
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Trigger pour la mise à jour automatique du timestamp updated_at
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ========================================
-- PHASE 6: TEMPLATES D'EMAIL OTP
-- ========================================

-- Supprimer les templates existants si nécessaire
DELETE FROM auth.email_templates WHERE template_type IN ('signup', 'recovery');

-- Insérer les templates d'email personnalisés pour MONTOIT
INSERT INTO auth.email_templates (template_type, subject, body, is_active) VALUES
(
    'signup', 
    'Vérifiez votre email - MONTOIT',
    '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; }
            .button { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
            .footer { background: #333; color: white; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🏠 MONTOIT</h1>
                <p>Votre plateforme immobilière de confiance</p>
            </div>
            <div class="content">
                <h2>Bienvenue sur MONTOIT !</h2>
                <p>Merci pour votre inscription. Votre compte a été créé avec succès.</p>
                <p>Pour finaliser votre inscription, cliquez sur le bouton ci-dessous pour vérifier votre adresse email :</p>
                <div style="text-align: center;">
                    <a href="{{ .ConfirmationURL }}" class="button">✅ Vérifier mon email</a>
                </div>
                <p><strong>Important :</strong> Ce lien de vérification expire dans 24 heures.</p>
                <p>Si vous n''avez pas demandé cette inscription, vous pouvez ignorer cet email en toute sécurité.</p>
            </div>
            <div class="footer">
                <p>© 2025 MONTOIT - Plateforme Immobilière<br>
                Abidjan, Côte d''Ivoire</p>
            </div>
        </div>
    </body>
    </html>', 
    true
),
(
    'recovery', 
    'Réinitialisation mot de passe - MONTOIT',
    '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; }
            .button { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
            .footer { background: #333; color: white; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔐 Réinitialisation de mot de passe</h1>
                <p>MONTOIT - Plateforme Immobilière</p>
            </div>
            <div class="content">
                <h2>Réinitialisation demandée</h2>
                <p>Nous avons reçu une demande de réinitialisation de mot de passe pour votre compte MONTOIT.</p>
                <p>Cliquez sur le bouton ci-dessous pour créer un nouveau mot de passe :</p>
                <div style="text-align: center;">
                    <a href="{{ .ConfirmationURL }}" class="button">🔄 Réinitialiser mon mot de passe</a>
                </div>
                <p><strong>Sécurité :</strong> Ce lien expire dans 1 heure pour votre sécurité.</p>
                <p>Si vous n''avez pas demandé cette réinitialisation, ignorez cet email et votre mot de passe restera inchangé.</p>
            </div>
            <div class="footer">
                <p>© 2025 MONTOIT - Plateforme Immobilière<br>
                Abidjan, Côte d''Ivoire</p>
            </div>
        </div>
    </body>
    </html>', 
    true
);

-- ========================================
-- PHASE 7: CONFIGURATION AUTH
-- ========================================

-- Configuration des paramètres d'authentification pour la production
UPDATE auth.config SET
    -- Désactiver l'auto-confirmation pour plus de sécurité
    mailer_autoconfirm = false,
    sms_autoconfirm = false,
    
    -- Activer les méthodes d'authentification
    external_email_enabled = true,
    external_phone_enabled = true,
    
    -- URLs de redirection pour production (à ajuster selon le domaine)
    external_url = 'https://somet1010-montoit-st-dzj4.bolt.host',
    site_url = 'https://somet1010-montoit-st-dzj4.bolt.host',
    
    -- Rotation des tokens de rafraîchissement
    REFRESH_TOKEN_ROTATION_ENABLED = true,
    
    -- Demander réauthentification pour les mises à jour de mot de passe
    SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION = true,
    
    -- Configuration JWT
    JWT_EXP = 3600,  -- 1 heure
    REFRESH_TOKEN_REUSE_INTERVAL = 10  -- 10 secondes

WHERE true;

-- ========================================
-- PHASE 8: CORRECTION DES UTILISATEURS EXISTANTS
-- ========================================

-- Corriger les utilisateurs existants sans profil
SELECT fix_existing_users() AS utilisateurs_corriges;

-- ========================================
-- PHASE 9: VUES ET MONITORING
-- ========================================

-- Créer une vue pour monitorer la santé du système d'authentification
CREATE OR REPLACE VIEW auth_health_dashboard AS
SELECT 
    -- Métriques d'inscription
    (SELECT COUNT(*) FROM auth.users WHERE DATE(created_at) = CURRENT_DATE) as inscriptions_aujourdhui,
    (SELECT COUNT(*) FROM auth.users WHERE created_at >= DATE_TRUNC('week', NOW())) as inscriptions_semaine,
    (SELECT COUNT(*) FROM auth.users WHERE created_at >= DATE_TRUNC('month', NOW())) as inscriptions_mois,
    
    -- Métriques de profils
    (SELECT COUNT(*) FROM public.profiles) as total_profils,
    (SELECT COUNT(*) FROM public.profiles WHERE email_verified = true) as emails_verifies,
    (SELECT COUNT(*) FROM public.profiles WHERE phone_verified = true) as phones_verifies,
    (SELECT COUNT(*) FROM auth.users u LEFT JOIN public.profiles p ON u.id = p.id WHERE p.id IS NULL) as profils_manquants,
    
    -- Utilisateurs actifs (sessions dans les 30 derniers jours)
    (SELECT COUNT(DISTINCT user_id) FROM auth.sessions WHERE created_at >= NOW() - INTERVAL '30 days') as utilisateurs_actifs_30j,
    
    -- Erreurs récentes
    (SELECT COUNT(*) FROM auth.audit_log_entries WHERE created_at >= NOW() - INTERVAL '24 hours' AND action LIKE '%error%') as erreurs_24h,
    (SELECT COUNT(*) FROM auth.audit_log_entries WHERE created_at >= NOW() - INTERVAL '7 days' AND action LIKE '%signup%') as tentatives_inscription_7j;

-- ========================================
-- PHASE 10: VALIDATION ET TESTS
-- ========================================

-- Validation: Vérifier que les tables sont correctement configurées
SELECT 
    'Validation de la configuration' as test_type,
    CASE 
        WHEN COUNT(*) > 0 THEN '✅ Configuration correcte'
        ELSE '⚠️ Vérification manuelle requise'
    END as status
FROM information_schema.tables 
WHERE table_schema = 'public' 
    AND table_name = 'profiles'

UNION ALL

SELECT 
    'Validation des triggers' as test_type,
    CASE 
        WHEN COUNT(*) > 0 THEN '✅ Triggers actifs'
        ELSE '❌ Aucun trigger trouvé'
    END as status
FROM information_schema.triggers 
WHERE trigger_name = 'on_auth_user_created'

UNION ALL

SELECT 
    'Validation des politiques RLS' as test_type,
    CASE 
        WHEN COUNT(*) >= 3 THEN '✅ Politiques RLS configurées'
        ELSE '❌ Politiques RLS manquantes'
    END as status
FROM pg_policies 
WHERE tablename = 'profiles';

-- Message de confirmation
SELECT 
    '🎉 Script de réparation Supabase exécuté avec succès!' as message,
    NOW() as date_execution,
    'Vérifiez les résultats ci-dessus pour confirmer la configuration' as next_steps;

-- ========================================
-- FIN DU SCRIPT
-- ========================================

-- Pour vérifier l'état après exécution, exécuter:
-- SELECT * FROM auth_health_dashboard;

-- Pour voir les utilisateurs récents:
-- SELECT created_at, email, raw_user_meta_data->>'full_name' as nom
-- FROM auth.users 
-- ORDER BY created_at DESC 
-- LIMIT 10;

-- Pour voir les profils créés:
-- SELECT id, full_name, email, verification_type, created_at
-- FROM public.profiles
-- ORDER BY created_at DESC
-- LIMIT 10;
