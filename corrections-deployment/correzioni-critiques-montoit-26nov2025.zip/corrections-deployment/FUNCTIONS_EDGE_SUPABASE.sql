-- ========================================
-- FONCTIONS EDGE SUPABASE - MONTOIT
-- Correction Erreurs Authentification
-- Date: 26 novembre 2025
-- ========================================

-- ========================================
-- FONCTION 1: Envoi Code OTP (Email/SMS/WhatsApp)
-- ========================================

-- Fichier: supabase/functions/send-verification-code/index.ts
-- Déployer avec: supabase functions deploy send-verification-code

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Twilio from 'https://esm.sh/twilio@4.21.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
}

serve(async (req) => {
  // Gestion CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders, status: 200 })
  }

  try {
    // Extraire les paramètres de la requête
    const { email, phone, type, name, timestamp } = await req.json()
    
    // Validation des paramètres
    if (!type || !['email', 'sms', 'whatsapp'].includes(type)) {
      throw new Error('Type de vérification invalide')
    }
    
    if (type === 'email' && !email) {
      throw new Error('Email requis pour la vérification par email')
    }
    
    if ((type === 'sms' || type === 'whatsapp') && !phone) {
      throw new Error('Téléphone requis pour la vérification par SMS/WhatsApp')
    }

    // Générer un code OTP sécurisé
    const generateOTP = () => {
      return Math.floor(100000 + Math.random() * 900000).toString()
    }
    
    const otpCode = generateOTP()
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000) // 10 minutes

    // Initialiser Supabase avec service role pour les opérations admin
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    // Envoyer le code selon la méthode
    let sendResult
    
    if (type === 'email') {
      // ✅ Envoi par email
      const { error: emailError } = await supabaseAdmin.auth.resend({
        type: 'signup',
        email: email,
        options: {
          emailRedirectTo: `${Deno.env.get('SITE_URL')}/verify-otp`,
          data: {
            otp_code: otpCode,
            user_name: name || 'Utilisateur',
            expires_at: expiresAt.toISOString()
          }
        }
      })

      if (emailError) {
        throw new Error(`Erreur envoi email: ${emailError.message}`)
      }
      
      sendResult = { method: 'email', status: 'sent' }
      
    } else if (type === 'sms') {
      // ✅ Envoi par SMS (Twilio)
      const twilio = Twilio(
        Deno.env.get('TWILIO_ACCOUNT_SID')!,
        Deno.env.get('TWILIO_AUTH_TOKEN')!
      )

      const message = `🏠 MONTOIT - Votre code de vérification est: ${otpCode}. Valable 10 minutes.`
      
      const twilioResult = await twilio.messages.create({
        body: message,
        from: Deno.env.get('TWILIO_PHONE_NUMBER'),
        to: phone
      })

      sendResult = { method: 'sms', status: 'sent', messageId: twilioResult.sid }
      
    } else if (type === 'whatsapp') {
      // ✅ Envoi par WhatsApp (Twilio)
      const twilio = Twilio(
        Deno.env.get('TWILIO_ACCOUNT_SID')!,
        Deno.env.get('TWILIO_AUTH_TOKEN')!
      )

      const message = `🏠 MONTOIT - Votre code de vérification: ${otpCode}\n\n✅ Valable 10 minutes\n🏠 MONTOIT - Plateforme Immobilière`
      
      const twilioResult = await twilio.messages.create({
        body: message,
        from: `whatsapp:${Deno.env.get('TWILIO_WHATSAPP_NUMBER')}`,
        to: `whatsapp:${phone}`
      })

      sendResult = { method: 'whatsapp', status: 'sent', messageId: twilioResult.sid }
    }

    // Sauvegarder le code OTP pour vérification ultérieure
    const { error: dbError } = await supabaseAdmin
      .from('otp_verifications')
      .upsert({
        email: email || null,
        phone: phone || null,
        otp_code: otpCode,
        type: type,
        expires_at: expiresAt.toISOString(),
        used: false,
        created_at: new Date().toISOString()
      }, {
        onConflict: 'email,phone'
      })

    if (dbError) {
      console.error('Erreur sauvegarde OTP:', dbError)
      // Ne pas faire échouer l'envoi si la sauvegarde échoue
    }

    // Log pour monitoring
    console.log(`OTP envoyé: ${type} à ${email || phone}`, {
      timestamp,
      otpHash: otpCode, // Note: En production, hacher ce log
      method: sendResult.method
    })

    // Retourner le succès
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Code envoyé avec succès par ${sendResult.method}`,
        data: {
          method: sendResult.method,
          expiresIn: 600, // 10 minutes en secondes
          sent: true
        }
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Erreur fonction send-verification-code:', error)
    
    return new Response(
      JSON.stringify({ 
        error: 'Erreur lors de l\'envoi du code de vérification',
        message: error.message,
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})

-- ========================================
-- FONCTION 2: Vérification Code OTP
-- ========================================

-- Fichier: supabase/functions/verify-otp/index.ts

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders, status: 200 })
  }

  try {
    const { otpCode, email, phone } = await req.json()
    
    if (!otpCode || (!email && !phone)) {
      throw new Error('Code OTP et email/téléphone requis')
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    // Rechercher le code OTP
    const { data: otpRecord, error: otpError } = await supabase
      .from('otp_verifications')
      .select('*')
      .eq('otp_code', otpCode)
      .or(`email.eq.${email},phone.eq.${phone}`)
      .eq('used', false)
      .single()

    if (otpError || !otpRecord) {
      throw new Error('Code OTP invalide ou déjà utilisé')
    }

    // Vérifier l'expiration
    const expiresAt = new Date(otpRecord.expires_at)
    if (expiresAt < new Date()) {
      throw new Error('Code OTP expiré')
    }

    // Marquer le code comme utilisé
    const { error: updateError } = await supabase
      .from('otp_verifications')
      .update({ 
        used: true, 
        used_at: new Date().toISOString() 
      })
      .eq('id', otpRecord.id)

    if (updateError) {
      throw new Error('Erreur lors de la vérification')
    }

    // Confirmer l'utilisateur si nécessaire
    if (email) {
      const { error: confirmError } = await supabase.auth.verifyOtp({
        token_hash: otpCode,
        type: 'email'
      })
      
      if (confirmError) {
        console.warn('Erreur confirmation email:', confirmError)
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Code vérifié avec succès',
        data: {
          verified: true,
          type: otpRecord.type
        }
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: 'Erreur lors de la vérification',
        message: error.message 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})

-- ========================================
-- FONCTION 3: Monitoring et Alertes
-- ========================================

-- Fichier: supabase/functions/auth-monitor/index.ts

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders, status: 200 })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    // Collecter les métriques
    const [inscriptionsToday, errorsLast24h, profilsManquants, activiteRecente] = await Promise.all([
      // Inscriptions aujourd'hui
      supabase.from('auth.users')
        .select('id', { count: 'exact', head: true })
        .gte('created_at', new Date().toISOString().split('T')[0]),
        
      // Erreurs dernières 24h
      supabase.from('auth.audit_log_entries')
        .select('id', { count: 'exact', head: true })
        .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
        .like('action', '%error%'),
        
      // Profils manquants
      supabase.rpc('count_profils_manquants'),
      
      // Activité récente
      supabase.from('auth.audit_log_entries')
        .select('action, created_at')
        .gte('created_at', new Date(Date.now() - 60 * 60 * 1000).toISOString())
        .order('created_at', { ascending: false })
    ])

    const metrics = {
      inscriptions_today: inscriptionsToday.count || 0,
      erreurs_24h: errorsLast24h.count || 0,
      profils_manquants: profilsManquants || 0,
      activite_derniere_heure: activiteRecente.data?.length || 0,
      timestamp: new Date().toISOString(),
      status: 'healthy'
    }

    // Déterminer le statut de santé
    if (metrics.erreurs_24h > 10) {
      metrics.status = 'critical'
    } else if (metrics.profils_manquants > 5) {
      metrics.status = 'warning'
    }

    // Sauvegarder les métriques
    await supabase.from('auth_metrics').insert({
      ...metrics,
      recorded_at: new Date().toISOString()
    })

    // Envoyer alerte si problème critique
    if (metrics.status === 'critical') {
      await sendAdminAlert(metrics, supabase)
    }

    return new Response(
      JSON.stringify(metrics),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Erreur monitoring:', error)
    
    return new Response(
      JSON.stringify({ 
        error: 'Erreur monitoring',
        status: 'error',
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})

async function sendAdminAlert(metrics: any, supabase: any) {
  try {
    // Envoi email d'alerte
    await supabase.functions.invoke('send-admin-notification', {
      body: {
        type: 'critical_auth_error',
        subject: '🚨 Alerte Critique - Système d\'Authentification MONTOIT',
        message: `Le système d'authentification rencontre des problèmes critiques:
        
        • Erreurs dernières 24h: ${metrics.erreurs_24h}
        • Profils manquants: ${metrics.profils_manquants}
        • Inscriptions aujourd'hui: ${metrics.inscriptions_today}
        
        Vérifiez le dashboard Supabase immédiatement.`,
        severity: 'critical'
      }
    })
  } catch (error) {
    console.error('Erreur envoi alerte:', error)
  }
}

-- ========================================
-- TABLE SUPPLÉMENTAIRES POUR LE MONITORING
-- ========================================

-- Table pour stocker les codes OTP
CREATE TABLE IF NOT EXISTS public.otp_verifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT,
    phone TEXT,
    otp_code TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('email', 'sms', 'whatsapp')),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Contrainte pour éviter les doublons
    UNIQUE(email, phone, otp_code)
);

-- Index pour optimiser les requêtes OTP
CREATE INDEX idx_otp_email ON public.otp_verifications(email) WHERE email IS NOT NULL;
CREATE INDEX idx_otp_phone ON public.otp_verifications(phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_otp_used ON public.otp_verifications(used, expires_at);

-- Table pour les métriques d'authentification
CREATE TABLE IF NOT EXISTS public.auth_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    inscriptions_today INTEGER DEFAULT 0,
    erreurs_24h INTEGER DEFAULT 0,
    profils_manquants INTEGER DEFAULT 0,
    activite_derniere_heure INTEGER DEFAULT 0,
    status TEXT NOT NULL CHECK (status IN ('healthy', 'warning', 'critical', 'error')),
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour les métriques
CREATE INDEX idx_auth_metrics_date ON public.auth_metrics(recorded_at DESC);
CREATE INDEX idx_auth_metrics_status ON public.auth_metrics(status);

-- Table pour les alertes administrateur
CREATE TABLE IF NOT EXISTS public.admin_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    error_type TEXT NOT NULL,
    details TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'critical')),
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour les alertes
CREATE INDEX idx_admin_alerts_severity ON public.admin_alerts(severity, created_at DESC);
CREATE INDEX idx_admin_alerts_resolved ON public.admin_alerts(resolved);

-- ========================================
-- FONCTION UTILITAIRE: Compter profils manquants
-- ========================================

CREATE OR REPLACE FUNCTION count_profils_manquants()
RETURNS INTEGER AS $$
BEGIN
    RETURN (
        SELECT COUNT(*)
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ========================================
-- FONCTION UTILITAIRE: Nettoyer anciens OTP
-- ========================================

CREATE OR REPLACE FUNCTION cleanup_expired_otp()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM public.otp_verifications 
    WHERE expires_at < NOW() - INTERVAL '1 hour';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ========================================
-- CRON JOB POUR LE NETTOYAGE AUTOMATIQUE
-- ========================================

-- Nettoyer les OTP expirés toutes les heures
SELECT cron.schedule(
    'cleanup-otp-codes',
    '0 * * * *',  -- Chaque heure
    'SELECT cleanup_expired_otp();'
);

-- Monitoring automatique toutes les 5 minutes
SELECT cron.schedule(
    'auth-health-check',
    '*/5 * * * *',  -- Toutes les 5 minutes
    $$
    SELECT net.http_post(
        url := 'https://' || current_setting('app.project_ref') || '.functions.supabase.co/auth-monitor',
        headers := '{"Authorization": "Bearer ' || current_setting('app.service_role_key') || '"}'
    );
    $$
);

-- ========================================
-- VUES POUR DASHBOARD
-- ========================================

-- Vue pour les métriques de performance
CREATE OR REPLACE VIEW auth_performance_metrics AS
SELECT 
    DATE_TRUNC('hour', recorded_at) as heure,
    AVG(inscriptions_today) as inscriptions_moyennes,
    AVG(erreurs_24h) as erreurs_moyennes,
    AVG(profils_manquants) as profils_manquants_moyens,
    MAX(status) as status_final
FROM auth_metrics
WHERE recorded_at >= NOW() - INTERVAL '24 hours'
GROUP BY DATE_TRUNC('hour', recorded_at)
ORDER BY heure DESC;

-- Vue pour les OTP utilisés/non utilisés
CREATE OR REPLACE VIEW otp_usage_stats AS
SELECT 
    type,
    COUNT(*) as total_otp,
    COUNT(CASE WHEN used = true THEN 1 END) as otp_utilises,
    COUNT(CASE WHEN used = false AND expires_at > NOW() THEN 1 END) as otp_en_attente,
    ROUND(
        COUNT(CASE WHEN used = true THEN 1 END) * 100.0 / COUNT(*), 2
    ) as taux_utilisation_pourcent
FROM otp_verifications
WHERE created_at >= NOW() - INTERVAL '7 days'
GROUP BY type
ORDER BY type;

-- ========================================
-- TRIGGER POUR MISE À JOUR AUTOMATIQUE
-- ========================================

CREATE OR REPLACE FUNCTION update_otp_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_otp_updated_at
    BEFORE UPDATE ON public.otp_verifications
    FOR EACH ROW EXECUTE FUNCTION update_otp_updated_at();

-- ========================================
-- POLITIQUE DE SÉCURITÉ POUR LES OTP
-- ========================================

-- RLS pour la table otp_verifications
ALTER TABLE public.otp_verifications ENABLE ROW LEVEL SECURITY;

-- Politique restrictive : seul le service role peut accéder aux OTP
CREATE POLICY "Service role only for otp" ON public.otp_verifications
    FOR ALL USING (auth.role() = 'service_role');

-- RLS pour les métriques d'auth
ALTER TABLE public.auth_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin read metrics" ON public.auth_metrics
    FOR SELECT USING (
        auth.jwt() ->> 'role' = 'admin' OR 
        auth.jwt() ->> 'email' = 'admin@montoit.ci'
    );

CREATE POLICY "Service role manage metrics" ON public.auth_metrics
    FOR ALL USING (auth.role() = 'service_role');

-- ========================================
-- REQUÊTES DE TEST ET VALIDATION
-- ========================================

-- Test de la fonction de monitoring
-- SELECT count_profils_manquants() as profils_manquants;

-- Test du nettoyage OTP
-- SELECT cleanup_expired_otp() as otp_nettoyes;

-- Vérifier les métriques récentes
-- SELECT * FROM auth_metrics ORDER BY recorded_at DESC LIMIT 10;

-- Statistiques OTP
-- SELECT * FROM otp_usage_stats;

-- ========================================
-- INSTRUCTIONS DE DÉPLOIEMENT
-- ========================================

/*
DÉPLOIEMENT DES FONCTIONS EDGE:

1. Installer Supabase CLI
2. Se connecter au projet:
   supabase login
   supabase link --project-ref tayhmawgohcocfnfhaku

3. Déployer les fonctions:
   supabase functions deploy send-verification-code
   supabase functions deploy verify-otp
   supabase functions deploy auth-monitor

4. Configurer les variables d'environnement:
   supabase secrets set TWILIO_ACCOUNT_SID=your_account_sid
   supabase secrets set TWILIO_AUTH_TOKEN=your_auth_token
   supabase secrets set TWILIO_PHONE_NUMBER=+1234567890
   supabase secrets set TWILIO_WHATSAPP_NUMBER=+1234567890
   supabase secrets set SITE_URL=https://your-domain.com

5. Exécuter le script SQL pour créer les tables
6. Tester les fonctions:
   curl -X POST 'https://tayhmawgohcocfnfhaku.functions.supabase.co/send-verification-code' \
     -H 'Content-Type: application/json' \
     -H 'Authorization: Bearer YOUR_ANON_KEY' \
     -d '{"email":"test@example.com","type":"email","name":"Test User"}'
*/
