# Guide d'Intégration Complet
## Synchronisation lovable-project ↔ lovable-project-revive-46

### 📋 Table des Matières
1. [Étapes de Synchronisation](#1-étapes-de-synchronisation)
2. [Commandes Git Nécessaires](#2-commandes-git-nécessaires)
3. [Vérifications Post-Intégration](#3-vérifications-post-intégration)
4. [Dépendances à Ajouter](#4-dépendances-à-ajouter)
5. [Variables d'Environnement](#5-variables-denvironnement)
6. [Tests à Effectuer](#6-tests-à-effectuer)
7. [Dépannage](#7-dépannage)

---

## 1. Étapes de Synchronisation

### 🚀 Phase 1 : Préparation
1. **Analyse comparative des structures**
   ```bash
   # Comparer les structures des deux projets
   diff -r /workspace/lovable-project/src /workspace/lovable-project-revive-46/src
   ```

2. **Identification des fichiers critiques**
   - `package.json` - Dépendances et scripts
   - `vite.config.ts` - Configuration Vite
   - `tsconfig.json` - Configuration TypeScript
   - `tailwind.config.ts` - Configuration Tailwind
   - `src/App.tsx` - Composant principal
   - `src/main.tsx` - Point d'entrée
   - Dossier `src/components` - Composants UI
   - Dossier `src/features` - Fonctionnalités métier

### 🔄 Phase 2 : Synchronisation du Code
1. **Copie des fichiers de configuration**
   ```bash
   # Copier les fichiers de configuration du projet de référence
   cp /workspace/ref-project/package.json /workspace/lovable-project-revive-46/
   cp /workspace/ref-project/vite.config.ts /workspace/lovable-project-revive-46/
   cp /workspace/ref-project/tsconfig*.json /workspace/lovable-project-revive-46/
   cp /workspace/ref-project/tailwind.config*.ts /workspace/lovable-project-revive-46/
   ```

2. **Synchronisation des composants**
   ```bash
   # Copier les composants Shadcn UI
   cp -r /workspace/ref-project/src/components/* /workspace/lovable-project-revive-46/src/components/
   ```

3. **Synchronisation des fonctionnalités**
   ```bash
   # Copier les fonctionnalités avancées
   cp -r /workspace/ref-project/src/features/* /workspace/lovable-project-revive-46/src/features/
   ```

### 🗺️ Phase 3 : Intégration Mapbox
1. **Structure des composants carte**
   ```
   src/
   ├── features/
   │   ├── map/
   │   │   ├── components/
   │   │   │   ├── PropertyMap.tsx
   │   │   │   ├── PropertyMarker.tsx
   │   │   │   ├── MapControls.tsx
   │   │   │   ├── HeatmapLayer.tsx
   │   │   │   └── ClusterMarker.tsx
   │   │   ├── hooks/
   │   │   │   ├── usePropertyMap.ts
   │   │   │   ├── useMapEvents.ts
   │   │   │   └── usePropertyClustering.ts
   │   │   ├── services/
   │   │   │   ├── mapboxService.ts
   │   │   │   └── propertyService.ts
   │   │   ├── types/
   │   │   │   └── map.types.ts
   │   │   └── utils/
   │   │       ├── clustering.ts
   │   │       └── geojson.ts
   ```

---

## 2. Commandes Git Nécessaires

### 📦 Initialisation du Repository
```bash
# Cloner le repository lovable-project-revive-46
git clone [URL_LOVABLE_PROJECT_REVIVE_46] /workspace/lovable-project-revive-46
cd /workspace/lovable-project-revive-46

# Configurer l'utilisateur Git
git config user.name "Votre Nom"
git config user.email "votre.email@exemple.com"
```

### 🌿 Gestion des Branches
```bash
# Créer une branche d'intégration
git checkout -b feature/integration-mapbox-advanced

# Créer des sous-branches pour chaque phase
git checkout -b feature/integration-ui-modern
git checkout -b feature/integration-maps
git checkout -b feature/integration-security
git checkout -b feature/integration-payments

# Retourner à la branche principale
git checkout feature/integration-mapbox-advanced
```

### 📋 Commandes de Synchronisation
```bash
# Ajouter le repository source comme remote
git remote add source /workspace/lovable-project

# Récupérer les dernières modifications
git fetch source

# Créer une branche de travail depuis la source
git checkout -b sync-from-source source/main

# Merger les changements
git merge --no-ff -m "Synchronisation avec lovable-project"

# Résoudre les conflits si nécessaire
git add .
git commit -m "Résolution des conflits de synchronisation"
```

### 💾 Sauvegarde et Rollback
```bash
# Créer un tag de sauvegarde avant intégration
git tag -a "pre-integration-$(date +%Y%m%d-%H%M%S)" -m "Sauvegarde avant intégration Mapbox"

# En cas de rollback
git reset --hard "pre-integration-20251207-170000"

# Créer une branche de recovery
git checkout -b recovery-rollback
```

### 🚀 Déploiement et Mise à Jour
```bash
# Commit des changements d'intégration
git add .
git commit -m "feat: intégration complète Mapbox et fonctionnalités avancées

- Ajout mapbox-gl et supercluster
- Composants carte interactifs
- Filtres avancés et heatmap
- Tests intégrés et validés"

# Push vers le repository distant
git push origin feature/integration-mapbox-advanced

# Créer une Pull Request
gh pr create --title "Intégration Mapbox et fonctionnalités avancées" --body "$(cat << 'EOF'
## 🎯 Objectif
Intégrer les fonctionnalités cartographiques avancées et les améliorations UI dans lovable-project-revive-46

## 📋 Changements
- ✅ Installation mapbox-gl et supercluster
- ✅ Composants carte interactifs (PropertyMap, HeatmapLayer)
- ✅ Système de clustering automatique
- ✅ Filtres géolocalisés avancés
- ✅ Interface Shadcn UI modernisée
- ✅ 🔍 Tests
- validation

## Tests complets et Tests unitaires : ✅ Passés
- Tests d'intégration : ✅ Passés
- Tests de performance : ✅ <2s
- Tests de régression : ✅ Aucune régression

## 📱 Compatibilité
- Desktop : ✅ Chrome, Firefox, Safari, Edge
- Mobile : ✅ iOS Safari, Android Chrome
- Tablette : ✅ iPad, Android tablets

## ⚡ Performance
- Temps de chargement initial : <3s
- Réactivité des interactions : <100ms
- Mémoire utilisée : <150MB
EOF
)"
```

---

## 3. Vérifications Post-Intégration

### ✅ Checklist de Validation

#### 🖥️ Interface Utilisateur
- [ ] **Composants Shadcn UI**
  - [ ] Button, Input, Card fonctionnels
  - [ ] Navigation fluide
  - [ ] Responsive design
  - [ ] Thème sombre/clair

- [ ] **Composants Carte**
  - [ ] PropertyMap s'affiche correctement
  - [ ] Markers des propriétés visibles
  - [ ] Heatmap activable/désactivable
  - [ ] Zoom et navigation fluide

#### 🗺️ Fonctionnalités Cartographiques
- [ ] **Mapbox GL**
  - [ ] Carte se charge sans erreur
  - [ ] Styles personnalisés appliqués
  - [ ] Contrôles de zoom fonctionnels
  - [ ] Attributions visibles

- [ ] **Clustering (Supercluster)**
  - [ ] Regroupement automatique des markers
  - [ ] Animation d'expansion des clusters
  - [ ] Performance avec >1000 propriétés
  - [ ] Gestion des niveaux de zoom

- [ ] **Filtres Intelligents**
  - [ ] Filtres par prix fonctionnels
  - [ ] Filtres par superficie
  - [ ] Filtres par localisation
  - [ ] Recherche géolocalisée

#### 🔧 Configuration Technique
- [ ] **Dépendances**
  - [ ] `package.json` mis à jour
  - [ ] `node_modules` installées
  - [ ] Versions compatibles
  - [ ] Pas de conflits

- [ ] **Variables d'Environnement**
  - [ ] `VITE_MAPBOX_TOKEN` configuré
  - [ ] Clés API valides
  - [ ] Accès Supabase fonctionnel

#### 📊 Performance
- [ ] **Métriques Techniques**
  - [ ] Bundle size < 5MB
  - [ ] Temps de build < 60s
  - [ ] Lighthouse score > 90
  - [ ] Core Web Vitals verts

#### 🧪 Tests
- [ ] **Tests Automatisés**
  - [ ] Tests unitaires : 100% passent
  - [ ] Tests d'intégration : Passent
  - [ ] Tests E2E : Passent
  - [ ] Couverture > 80%

### 🔍 Commandes de Vérification
```bash
# Vérifier la structure des fichiers
find /workspace/lovable-project-revive-46/src -name "*.tsx" -o -name "*.ts" | head -20

# Vérifier les dépendances
npm list mapbox-gl supercluster

# Lancer les tests
npm run test
npm run test:e2e

# Build de production
npm run build

# Vérifier le bundle
npx vite-bundle-analyzer dist
```

---

## 4. Dépendances à Ajouter

### 📦 Dependencies Principales

#### Cartographie et Géolocalisation
```json
{
  "mapbox-gl": "^3.15.0",
  "react-map-gl": "^7.1.7",
  "@mapbox/mapbox-gl-draw": "^1.5.0",
  "@mapbox/mapbox-gl-geocoder": "^5.1.2",
  "supercluster": "^8.0.1",
  "@turf/turf": "^7.2.0"
}
```

#### Interface Utilisateur (Shadcn UI)
```json
{
  "@radix-ui/react-dialog": "^1.1.14",
  "@radix-ui/react-dropdown-menu": "^2.1.15",
  "@radix-ui/react-select": "^2.2.5",
  "@radix-ui/react-slider": "^1.3.5",
  "@radix-ui/react-tabs": "^1.1.12",
  "@radix-ui/react-toast": "^1.2.14",
  "class-variance-authority": "^0.7.1",
  "clsx": "^2.1.1",
  "tailwind-merge": "^2.6.0",
  "lucide-react": "^0.462.0"
}
```

#### Utilitaires et Helpers
```json
{
  "zod": "^3.25.76",
  "react-hook-form": "^7.61.1",
  "@hookform/resolvers": "^3.10.0",
  "date-fns": "^3.6.0",
  "framer-motion": "^12.23.24"
}
```

### 🛠️ DevDependencies
```json
{
  "@types/mapbox-gl": "^3.4.0",
  "@types/supercluster": "^7.1.0",
  "autoprefixer": "^10.4.21",
  "postcss": "^8.5.6",
  "tailwindcss": "^3.4.17",
  "@tailwindcss/typography": "^0.5.16",
  "vitest": "^3.2.4",
  "@vitest/ui": "^3.2.4"
}
```

### 📋 Commande d'Installation
```bash
# Installation complète des dépendances
npm install mapbox-gl@^3.15.0 \
            react-map-gl@^7.1.7 \
            @mapbox/mapbox-gl-draw@^1.5.0 \
            @mapbox/mapbox-gl-geocoder@^5.1.2 \
            supercluster@^8.0.1 \
            @turf/turf@^7.2.0 \
            @types/mapbox-gl@^3.4.0 \
            @types/supercluster@^7.1.0

# Installation Shadcn UI
npx shadcn-ui@latest init
npx shadcn-ui@latest add button input card dialog dropdown-menu select slider tabs toast

# Installation des utilitaires
npm install zod react-hook-form @hookform/resolvers date-fns framer-motion

# Installation des devDependencies
npm install -D vitest @vitest/ui @tailwindcss/typography
```

---

## 5. Variables d'Environnement

### 🔑 Variables Requises

#### Fichier `.env.local`
```bash
# Mapbox Configuration
VITE_MAPBOX_ACCESS_TOKEN=pk.eyJ1IjoieW91ci11c2VybmFtZSIsImEiOiJjbGV4YW1wbGUifQ.example_token_here
VITE_MAPBOX_STYLE=mapbox://styles/mapbox/streets-v12

# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# API Configuration
VITE_API_BASE_URL=https://api.yourdomain.com
VITE_API_TIMEOUT=30000

# Feature Flags
VITE_ENABLE_HEATMAP=true
VITE_ENABLE_CLUSTERING=true
VITE_ENABLE_DRAW_CONTROLS=true

# Performance Settings
VITE_MAP_CLUSTER_RADIUS=50
VITE_MAP_MAX_ZOOM=18
VITE_MAP_MIN_ZOOM=10

# Analytics (Optionnel)
VITE_ENABLE_ANALYTICS=true
VITE_GA_TRACKING_ID=G-XXXXXXXXXX
```

#### Configuration Supabase (.env.supabase)
```bash
# Variables côté serveur uniquement
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
SUPABASE_JWT_SECRET=your_jwt_secret
```

### ⚙️ Configuration Vite
```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,webp}']
      }
    })
  ],
  define: {
    'process.env': process.env
  },
  envPrefix: 'VITE_',
  server: {
    port: 3000,
    host: true
  },
  build: {
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          mapbox: ['mapbox-gl', 'react-map-gl'],
          ui: ['@radix-ui/react-dialog', '@radix-ui/react-dropdown-menu']
        }
      }
    }
  }
})
```

### 🔧 Configuration TypeScript
```json
// tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"],
      "@/components/*": ["./src/components/*"],
      "@/features/*": ["./src/features/*"],
      "@/lib/*": ["./src/lib/*"],
      "@/types/*": ["./src/types/*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

---

## 6. Tests à Effectuer

### 🧪 Stratégie de Tests

#### 1. Tests Unitaires
```typescript
// tests/components/PropertyMap.test.tsx
import { render, screen, waitFor } from '@testing-library/react'
import { PropertyMap } from '@/features/map/components/PropertyMap'
import { MapboxProvider } from '@/features/map/contexts/MapboxContext'

describe('PropertyMap', () => {
  it('should render without crashing', async () => {
    render(
      <MapboxProvider>
        <PropertyMap properties={mockProperties} />
      </MapboxProvider>
    )
    
    await waitFor(() => {
      expect(screen.getByTestId('mapbox-map')).toBeInTheDocument()
    })
  })

  it('should display property markers', async () => {
    render(
      <MapboxProvider>
        <PropertyMap properties={mockProperties} />
      </MapboxProvider>
    )
    
    await waitFor(() => {
      expect(screen.getAllByTestId('property-marker')).toHaveLength(mockProperties.length)
    })
  })

  it('should handle clustering for multiple properties', async () => {
    const manyProperties = Array.from({ length: 100 }, (_, i) => ({
      ...mockProperty,
      id: i.toString()
    }))
    
    render(
      <MapboxProvider>
        <PropertyMap properties={manyProperties} />
      </MapboxProvider>
    )
    
    await waitFor(() => {
      const clusters = screen.getAllByTestId('cluster-marker')
      expect(clusters.length).toBeGreaterThan(0)
    })
  })
})
```

#### 2. Tests d'Intégration
```typescript
// tests/integration/map-workflow.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MapPage } from '@/pages/MapPage'

describe('Carte - Workflow Complet', () => {
  it('should allow filtering and searching properties', async () => {
    const user = userEvent.setup()
    render(<MapPage />)
    
    // Ouvrir les filtres
    await user.click(screen.getByText('Filtres'))
    
    // Définir un prix maximum
    const priceInput = screen.getByLabelText('Prix maximum')
    await user.clear(priceInput)
    await user.type(priceInput, '500000')
    
    // Appliquer les filtres
    await user.click(screen.getByText('Appliquer'))
    
    // Vérifier les résultats filtrés
    await waitFor(() => {
      const markers = screen.getAllByTestId('property-marker')
      markers.forEach(marker => {
        expect(marker).toHaveAttribute('data-price', expect.stringMatching(/^[0-5][0-9]{5}$/))
      })
    })
  })

  it('should show heatmap when enabled', async () => {
    const user = userEvent.setup()
    render(<MapPage />)
    
    // Activer la heatmap
    await user.click(screen.getByText('Heatmap'))
    
    // Vérifier que la heatmap est visible
    await waitFor(() => {
      expect(screen.getByTestId('heatmap-layer')).toBeInTheDocument()
    })
  })
})
```

#### 3. Tests de Performance
```typescript
// tests/performance/map-performance.test.ts
import { PerformanceObserver, performance } from 'perf_hooks'
import { render } from '@testing-library/react'
import { PropertyMap } from '@/features/map/components/PropertyMap'

describe('Performance - Carte', () => {
  it('should load map within acceptable time', async () => {
    const start = performance.now()
    
    render(<PropertyMap properties={mockProperties} />)
    
    const end = performance.now()
    const loadTime = end - start
    
    expect(loadTime).toBeLessThan(2000) // < 2 secondes
  })

  it('should handle 1000+ properties efficiently', async () => {
    const manyProperties = Array.from({ length: 1000 }, (_, i) => ({
      ...mockProperty,
      id: i.toString(),
      coordinates: [Math.random() * 10 + 48, Math.random() * 10 + 2]
    }))
    
    const start = performance.now()
    render(<PropertyMap properties={manyProperties} />)
    
    await new Promise(resolve => setTimeout(resolve, 100))
    const end = performance.now()
    
    const renderTime = end - start
    expect(renderTime).toBeLessThan(1000) // < 1 seconde pour 1000 propriétés
  })
})
```

### 🚀 Commandes de Test
```bash
# Tests unitaires
npm run test

# Tests avec coverage
npm run test:coverage

# Tests d'intégration
npm run test:integration

# Tests E2E avec Playwright
npm run test:e2e

# Tests de performance
npm run test:performance

# Tests complets (CI/CD)
npm run test:all

# Tests en mode watch
npm run test:watch

# Tests spécifiques
npm test -- --testNamePattern="PropertyMap"

# Tests avec couverture détaillée
npm run test:coverage -- --coverageReporters=html
```

### 📊 Métriques de Performance
```bash
# Analyser le bundle
npm run build
npx vite-bundle-analyzer dist

# Performance Lighthouse
npx lighthouse http://localhost:3000 --output=json --output-path=./lighthouse-report.json

# Core Web Vitals
npm run analyze-performance

# Tests de charge avec k6
k6 run tests/load/map-load-test.js
```

### ✅ Tests de Régression
```bash
# Snapshot tests pour les composants UI
npm run test:snapshots

# Tests visuels avec Chromatic
npx chromatic --project-token=your_token

# Tests de compatibilité cross-browser
npm run test:browsers

# Tests de responsivité
npm run test:responsive
```

---

## 7. Dépannage

### 🐛 Problèmes Courants

#### 1. Erreur Mapbox GL
```
Error: Could not find a valid Mapbox GL JS CSS file
```
**Solution :**
```bash
# Ajouter l'import CSS dans main.tsx
import 'mapbox-gl/dist/mapbox-gl.css'
```

#### 2. Problème de Clustering
```
Error: Supercluster index is not initialized
```
**Solution :**
```typescript
// Initialiser supercluster correctement
const index = new Supercluster({
  radius: 60,
  maxZoom: 16
}).load(geoJsonData)
```

#### 3. Conflits de Dépendances
```
Error: Multiple versions of mapbox-gl found
```
**Solution :**
```bash
# Nettoyer et réinstaller
rm -rf node_modules package-lock.json
npm install

# Vérifier les versions
npm ls mapbox-gl
```

#### 4. Variables d'Environnement
```
Error: VITE_MAPBOX_ACCESS_TOKEN is not defined
```
**Solution :**
```bash
# Vérifier le fichier .env.local
cat .env.local | grep VITE_MAPBOX

# Redémarrer le serveur de dev
npm run dev
```

### 🔧 Commandes de Debug
```bash
# Vérifier la configuration
npm run analyze

# Logs détaillés
DEBUG=mapboxgl:* npm run dev

# Vérifier les imports
npm run analyze-imports

# Test de build local
npm run build:analyze
```

### 📞 Support et Ressources
- **Documentation Mapbox GL JS** : https://docs.mapbox.com/mapbox-gl-js/
- **Supercluster Documentation** : https://github.com/mapbox/supercluster
- **React Map GL** : https://visgl.github.io/react-map-gl/
- **Shadcn UI** : https://ui.shadcn.com/

---

## 📝 Checklist Finale

### ✅ Pré-Intégration
- [ ] Repository lovable-project-revive-46 cloné
- [ ] Branche feature/integration créée
- [ ] Sauvegarde initiale effectuée
- [ ] Environnement configuré

### ✅ Intégration
- [ ] Dépendances installées
- [ ] Variables d'environnement configurées
- [ ] Composants carte intégrés
- [ ] Tests implémentés
- [ ] Build fonctionnel

### ✅ Validation
- [ ] Tests unitaires passent (100%)
- [ ] Tests d'intégration passent
- [ ] Performance validée (<2s)
- [ ] Responsive design vérifié
- [ ] Accessibilité validée

### ✅ Déploiement
- [ ] Build de production créé
- [ ] Bundle size optimisé (<5MB)
- [ ] Déploiement en staging
- [ ] Tests E2E en staging
- [ ] Validation utilisateur
- [ ] Déploiement en production

### ✅ Post-Déploiement
- [ ] Monitoring activé
- [ ] Analytics configurés
- [ ] Logs surveillés
- [ ] Performance monitorée
- [ ] Feedback utilisateur collecté

---

**📧 Contact Support :** support@montoit.ci  
**📱 Urgence :** +225 XX XX XX XX  
**🔗 Repository :** https://github.com/montoit/lovable-project-revive-46  
**📚 Documentation :** https://docs.montoit.ci  

*Dernière mise à jour : 07/12/2025 à 17:00*