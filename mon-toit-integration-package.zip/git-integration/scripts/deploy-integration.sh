#!/bin/bash

# ==============================================================================
# Script de Déploiement Automatisé - Git Integration
# ==============================================================================
# Description: Script pour déployer l'application d'intégration Git
# Auteur: Système automatisé
# Date: 2025-12-07
# Version: 1.0
# ==============================================================================

set -euo pipefail  # Exit on error, undefined variables, pipe failures

# Configuration des couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables de configuration
PROJECT_NAME="git-integration"
DEPLOY_DIR="/opt/git-integration"
BACKUP_DIR="/opt/backups/git-integration"
LOG_FILE="/var/log/git-integration-deploy.log"
SERVICE_NAME="git-integration"

# Fonctions utilitaires
log() {
    local message="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${BLUE}[${timestamp}]${NC} $message" | tee -a "$LOG_FILE"
}

success() {
    local message="$1"
    echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOG_FILE"
}

warning() {
    local message="$1"
    echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOG_FILE"
}

error() {
    local message="$1"
    echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOG_FILE"
    exit 1
}

# Vérification des prérequis
check_prerequisites() {
    log "Vérification des prérequis..."
    
    # Vérifier si l'utilisateur a les privilèges sudo
    if [[ $EUID -eq 0 ]]; then
        error "Ce script ne doit pas être exécuté en tant que root. Utilisez un utilisateur avec sudo."
    fi
    
    # Vérifier la présence des outils requis
    local required_tools=("git" "docker" "docker-compose" "curl")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            error "L'outil '$tool' n'est pas installé ou n'est pas dans le PATH."
        fi
    done
    
    # Vérifier l'espace disque (minimum 2GB)
    local available_space=$(df /opt | awk 'NR==2 {print $4}')
    local required_space=2097152  # 2GB en KB
    
    if [[ $available_space -lt $required_space ]]; then
        error "Espace disque insuffisant. Minimum requis: 2GB, disponible: $((available_space/1024/1024))GB"
    fi
    
    success "Tous les prérequis sont satisfaits."
}

# Créer la sauvegarde avant déploiement
create_backup() {
    log "Création de la sauvegarde..."
    
    if [[ -d "$DEPLOY_DIR" ]]; then
        local backup_name="backup-$(date +%Y%m%d-%H%M%S)"
        sudo mkdir -p "$BACKUP_DIR"
        
        if sudo tar -czf "$BACKUP_DIR/$backup_name.tar.gz" -C "$DEPLOY_DIR" . 2>/dev/null; then
            success "Sauvegarde créée: $BACKUP_DIR/$backup_name.tar.gz"
        else
            warning "Impossible de créer la sauvegarde (répertoire vide ou permissions insuffisantes)."
        fi
    else
        warning "Aucun déploiement précédent trouvé, sauvegarde ignorée."
    fi
}

# Cloner ou mettre à jour le repository
update_source_code() {
    log "Mise à jour du code source..."
    
    local target_dir="$DEPLOY_DIR/source"
    local repo_url="${REPO_URL:-https://github.com/example/git-integration.git}"
    
    sudo mkdir -p "$target_dir"
    cd "$target_dir"
    
    if [[ -d ".git" ]]; then
        log "Mise à jour du repository existant..."
        sudo git fetch origin
        sudo git reset --hard origin/main
    else
        log "Clonage du repository..."
        sudo git clone "$repo_url" .
    fi
    
    success "Code source mis à jour."
}

# Construire et démarrer les conteneurs
deploy_application() {
    log "Déploiement de l'application..."
    
    cd "$DEPLOY_DIR/source"
    
    # Arrêter les conteneurs existants
    if [[ -f "docker-compose.yml" ]]; then
        sudo docker-compose down || warning "Aucun conteneur à arrêter."
    fi
    
    # Construire les nouvelles images
    log "Construction des images Docker..."
    sudo docker-compose build --no-cache
    
    # Démarrer les services
    log "Démarrage des services..."
    sudo docker-compose up -d
    
    # Attendre que les services soient prêts
    log "Attente de l'initialisation des services..."
    sleep 30
    
    success "Application déployée avec succès."
}

# Vérifier l'état des services
verify_deployment() {
    log "Vérification de l'état du déploiement..."
    
    local max_attempts=30
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        log "Tentative $attempt/$max_attempts - Vérification de l'état des services..."
        
        # Vérifier si les conteneurs sont en cours d'exécution
        local running_containers=$(sudo docker-compose ps --services --filter "status=running" | wc -l)
        local total_containers=$(sudo docker-compose ps --services | wc -l)
        
        if [[ $running_containers -eq $total_containers ]] && [[ $total_containers -gt 0 ]]; then
            log "Test de connectivité..."
            
            # Test de connectivité basique
            if sudo docker-compose exec -T app curl -f http://localhost:3000/health 2>/dev/null; then
                success "Déploiement vérifié avec succès!"
                return 0
            else
                warning "Services démarrés mais l'endpoint health check n'est pas accessible."
            fi
        fi
        
        ((attempt++))
        sleep 10
    done
    
    error "Échec de la vérification du déploiement après $max_attempts tentatives."
}

# Nettoyer les anciennes ressources
cleanup() {
    log "Nettoyage des ressources..."
    
    # Supprimer les images inutilisées
    sudo docker system prune -f
    
    # Nettoyer les logs anciens
    if [[ -f "$LOG_FILE" ]]; then
        sudo find /var/log -name "git-integration-*.log" -mtime +7 -delete 2>/dev/null || true
    fi
    
    success "Nettoyage terminé."
}

# Fonction principale
main() {
    local script_name=$(basename "$0")
    
    # Affichage de l'en-tête
    echo -e "${BLUE}=================================================================${NC}"
    echo -e "${BLUE}          Script de Déploiement - Git Integration${NC}"
    echo -e "${BLUE}=================================================================${NC}"
    echo
    
    # Demander confirmation si interactif
    if [[ -t 0 ]]; then
        read -p "Confirmer le déploiement? [y/N]: " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log "Déploiement annulé par l'utilisateur."
            exit 0
        fi
    fi
    
    # Exécution du processus de déploiement
    {
        check_prerequisites
        create_backup
        update_source_code
        deploy_application
        verify_deployment
        cleanup
        
        success "Déploiement terminé avec succès!"
        echo
        echo -e "${GREEN}Services disponibles:${NC}"
        echo -e "  - Application: http://localhost:3000"
        echo -e "  - Logs: $LOG_FILE"
        echo -e "  - Sauvegardes: $BACKUP_DIR"
        
    } || {
        error "Échec du déploiement. Consultez les logs pour plus d'informations: $LOG_FILE"
    }
}

# Gestion des signaux pour arrêt propre
trap 'error "Déploiement interrompu par un signal."' INT TERM

# Vérification des arguments
while getopts ":r:h" opt; do
    case $opt in
        r)
            REPO_URL="$OPTARG"
            ;;
        h)
            echo "Usage: $0 [-r REPO_URL]"
            echo "  -r REPO_URL    URL du repository Git (optionnel)"
            echo "  -h             Afficher cette aide"
            exit 0
            ;;
        \?)
            echo "Option invalide: -$OPTARG" >&2
            exit 1
            ;;
    esac
done

# Exécution du script principal
main "$@"