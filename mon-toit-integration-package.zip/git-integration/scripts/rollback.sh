#!/bin/bash

# ==============================================================================
# Script de Rollback - Git Integration
# ==============================================================================
# Description: Script pour revenir à une version précédente en cas de problème
# Auteur: Système automatisé
# Date: 2025-12-07
# Version: 1.0
# ==============================================================================

set -euo pipefail  # Exit on error, undefined variables, pipe failures

# Configuration des couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Variables de configuration
PROJECT_NAME="git-integration"
DEPLOY_DIR="/opt/git-integration"
BACKUP_DIR="/opt/backups/git-integration"
LOG_FILE="/var/log/git-integration-rollback.log"
SERVICE_NAME="git-integration"
MAX_BACKUPS_TO_KEEP=10

# Fonctions utilitaires
log() {
    local message="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${BLUE}[${timestamp}]${NC} $message" | tee -a "$LOG_FILE"
}

success() {
    local message="$1"
    echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOG_FILE"
}

warning() {
    local message="$1"
    echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOG_FILE"
}

error() {
    local message="$1"
    echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOG_FILE"
    exit 1
}

info() {
    local message="$1"
    echo -e "${MAGENTA}[INFO]${NC} $message" | tee -a "$LOG_FILE"
}

# Vérification des prérequis
check_prerequisites() {
    log "Vérification des prérequis pour le rollback..."
    
    # Vérifier si l'utilisateur a les privilèges sudo
    if [[ $EUID -eq 0 ]]; then
        error "Ce script ne doit pas être exécuté en tant que root. Utilisez un utilisateur avec sudo."
    fi
    
    # Vérifier la présence des outils requis
    local required_tools=("docker" "docker-compose" "tar")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            error "L'outil '$tool' n'est pas installé ou n'est pas dans le PATH."
        fi
    done
    
    # Vérifier que Docker est en cours d'exécution
    if ! docker info &> /dev/null; then
        error "Docker n'est pas en cours d'exécution."
    fi
    
    success "Tous les prérequis sont satisfaits."
}

# Lister les sauvegardes disponibles
list_available_backups() {
    log "Recherche des sauvegardes disponibles..."
    
    if [[ ! -d "$BACKUP_DIR" ]]; then
        error "Répertoire de sauvegarde non trouvé: $BACKUP_DIR"
    fi
    
    local backups=()
    while IFS= read -r -d '' file; do
        backups+=("$file")
    done < <(find "$BACKUP_DIR" -name "backup-*.tar.gz" -print0 2>/dev/null | sort -rz)
    
    if [[ ${#backups[@]} -eq 0 ]]; then
        error "Aucune sauvegarde trouvée dans $BACKUP_DIR"
    fi
    
    echo -e "${BLUE}Sauvegardes disponibles:${NC}"
    echo "================================"
    
    local counter=1
    local backup_array=()
    
    for backup in "${backups[@]}"; do
        local backup_name=$(basename "$backup")
        local backup_size=$(du -h "$backup" | cut -f1)
        local backup_date=$(stat -c %y "$backup" | cut -d. -f1)
        
        echo -e "${counter}. ${GREEN}$backup_name${NC}"
        echo "   Taille: $backup_size | Date: $backup_date"
        echo "   Chemin: $backup"
        echo
        
        backup_array+=("$backup")
        ((counter++))
    done
    
    # Retourner le tableau des sauvegardes
    printf '%s\n' "${backup_array[@]}"
}

# Créer une sauvegarde de l'état actuel avant rollback
backup_current_state() {
    log "Création d'une sauvegarde de l'état actuel..."
    
    if [[ -d "$DEPLOY_DIR" ]]; then
        local backup_name="pre-rollback-$(date +%Y%m%d-%H%M%S)"
        
        if sudo tar -czf "$BACKUP_DIR/$backup_name.tar.gz" -C "$DEPLOY_DIR" . 2>/dev/null; then
            success "Sauvegarde de l'état actuel créée: $BACKUP_DIR/$backup_name.tar.gz"
            return 0
        else
            warning "Impossible de créer la sauvegarde de l'état actuel."
            return 1
        fi
    else
        warning "Aucun déploiement actuel trouvé, sauvegarde ignorée."
        return 1
    fi
}

# Arrêter les services actuels
stop_current_services() {
    log "Arrêt des services actuels..."
    
    if [[ -f "$DEPLOY_DIR/source/docker-compose.yml" ]]; then
        cd "$DEPLOY_DIR/source"
        
        # Arrêter les conteneurs
        if sudo docker-compose down --remove-orphans; then
            success "Services arrêtés avec succès."
        else
            warning "Algunos servicios pueden no haberse detenido correctamente."
        fi
        
        # Supprimer les conteneurs et images orphelins
        sudo docker system prune -f &> /dev/null || true
    else
        warning "Aucun docker-compose.yml trouvé, skipping arrêt des services."
    fi
}

# Restaurer depuis une sauvegarde
restore_from_backup() {
    local backup_path="$1"
    
    log "Restauration depuis la sauvegarde: $(basename "$backup_path")"
    
    # Arrêter les services
    stop_current_services
    
    # Supprimer le déploiement actuel
    if [[ -d "$DEPLOY_DIR" ]]; then
        log "Suppression du déploiement actuel..."
        sudo rm -rf "$DEPLOY_DIR"/*
    fi
    
    # Restaurer la sauvegarde
    log "Extraction de la sauvegarde..."
    if sudo tar -xzf "$backup_path" -C "$DEPLOY_DIR"; then
        success "Sauvegarde restaurée avec succès."
    else
        error "Échec de la restauration de la sauvegarde."
    fi
    
    # Ajuster les permissions
    sudo chown -R $(whoami):$(whoami) "$DEPLOY_DIR" 2>/dev/null || true
    sudo chmod -R 755 "$DEPLOY_DIR" 2>/dev/null || true
}

# Redémarrer les services
restart_services() {
    log "Redémarrage des services..."
    
    if [[ -f "$DEPLOY_DIR/source/docker-compose.yml" ]]; then
        cd "$DEPLOY_DIR/source"
        
        # Construire et démarrer les services
        if sudo docker-compose up -d --build; then
            success "Services redémarrés avec succès."
            
            # Attendre l'initialisation
            log "Attente de l'initialisation des services..."
            sleep 30
            
            return 0
        else
            error "Échec du redémarrage des services."
        fi
    else
        error "Aucun docker-compose.yml trouvé pour redémarrer les services."
    fi
}

# Vérifier l'état après rollback
verify_rollback() {
    log "Vérification de l'état après rollback..."
    
    local max_attempts=20
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        log "Tentative $attempt/$max_attempts - Vérification de l'état..."
        
        # Vérifier les conteneurs
        local running_containers=$(docker ps --filter "name=git-integration" --format "{{.Names}}" | wc -l)
        local total_containers=$(docker ps -a --filter "name=git-integration" --format "{{.Names}}" | wc -l)
        
        if [[ $running_containers -gt 0 ]]; then
            log "Test de connectivité..."
            
            # Test de connectivité
            if curl -f -s http://localhost:3000/health &> /dev/null; then
                success "Rollback vérifié avec succès!"
                
                # Afficher l'état des conteneurs
                echo -e "${GREEN}Conteneurs en cours d'exécution:${NC}"
                docker ps --filter "name=git-integration" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
                
                return 0
            else
                warning "Conteneurs démarrés mais l'endpoint n'est pas accessible."
            fi
        else
            warning "Aucun conteneur en cours d'exécution."
        fi
        
        ((attempt++))
        sleep 10
    done
    
    error "Échec de la vérification du rollback après $max_attempts tentatives."
}

# Nettoyer les anciennes sauvegardes
cleanup_old_backups() {
    log "Nettoyage des anciennes sauvegardes..."
    
    if [[ -d "$BACKUP_DIR" ]]; then
        local backup_count=$(find "$BACKUP_DIR" -name "backup-*.tar.gz" | wc -l)
        
        if [[ $backup_count -gt $MAX_BACKUPS_TO_KEEP ]]; then
            local to_remove=$((backup_count - MAX_BACKUPS_TO_KEEP))
            log "Suppression de $to_remove ancienne(s) sauvegarde(s)..."
            
            find "$BACKUP_DIR" -name "backup-*.tar.gz" -printf '%T@ %p\n' | sort -n | head -n "$to_remove" | cut -d' ' -f2- | while read -r file; do
                if rm "$file"; then
                    info "Sauvegarde supprimée: $(basename "$file")"
                else
                    warning "Impossible de supprimer: $(basename "$file")"
                fi
            done
        else
            info "Nombre de sauvegardes acceptable: $backup_count"
        fi
    fi
}

# Rollback automatique (dernière sauvegarde)
rollback_automatic() {
    log "Recherche de la sauvegarde la plus récente..."
    
    local latest_backup=$(find "$BACKUP_DIR" -name "backup-*.tar.gz" -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)
    
    if [[ -n "$latest_backup" ]]; then
        info "Sauvegarde la plus récente trouvée: $(basename "$latest_backup")"
        
        if [[ -t 0 ]]; then
            read -p "Confirmer le rollback vers cette sauvegarde? [y/N]: " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                log "Rollback annulé par l'utilisateur."
                exit 0
            fi
        fi
        
        perform_rollback "$latest_backup"
    else
        error "Aucune sauvegarde trouvée pour le rollback automatique."
    fi
}

# Fonction principale de rollback
perform_rollback() {
    local backup_path="$1"
    
    {
        check_prerequisites
        
        # Créer une sauvegarde de l'état actuel
        backup_current_state
        
        # Exécuter le rollback
        restore_from_backup "$backup_path"
        restart_services
        verify_rollback
        
        # Nettoyer les anciennes sauvegardes
        cleanup_old_backups
        
        success "Rollback terminé avec succès!"
        echo
        echo -e "${GREEN}Services restaurés:${NC}"
        echo -e "  - Application: http://localhost:3000"
        echo -e "  - Logs: $LOG_FILE"
        echo -e "  - Sauvegardes: $BACKUP_DIR"
        
    } || {
        error "Échec du rollback. Consultez les logs pour plus d'informations: $LOG_FILE"
    }
}

# Fonction principale interactive
interactive_rollback() {
    log "Mode interactif de rollback"
    
    # Lister les sauvegardes
    local backups=($(list_available_backups))
    
    if [[ ${#backups[@]} -eq 0 ]]; then
        error "Aucune sauvegarde disponible."
    fi
    
    # Demander à l'utilisateur de choisir
    echo
    echo "Sélectionnez la sauvegarde pour le rollback:"
    read -p "Numéro de la sauvegarde (1-${#backups[@]}): " choice
    
    # Valider le choix
    if [[ ! "$choice" =~ ^[0-9]+$ ]] || [[ $choice -lt 1 ]] || [[ $choice -gt ${#backups[@]} ]]; then
        error "Choix invalide. Veuillez sélectionner un numéro entre 1 et ${#backups[@]}."
    fi
    
    # Obtenir le chemin de la sauvegarde sélectionnée
    local selected_backup="${backups[$((choice-1))]}"
    
    info "Sauvegarde sélectionnée: $(basename "$selected_backup")"
    
    # Demander confirmation
    if [[ -t 0 ]]; then
        read -p "Confirmer le rollback vers cette sauvegarde? [y/N]: " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log "Rollback annulé par l'utilisateur."
            exit 0
        fi
    fi
    
    perform_rollback "$selected_backup"
}

# Fonction principale
main() {
    local script_name=$(basename "$0")
    
    # Affichage de l'en-tête
    echo -e "${RED}=================================================================${NC}"
    echo -e "${RED}          Script de Rollback - Git Integration${NC}"
    echo -e "${RED}=================================================================${NC}"
    echo -e "${YELLOW}ATTENTION: Ce script va restaurer une version précédente${NC}"
    echo -e "${YELLOW}de l'application. Assurez-vous de comprendre les conséquences.${NC}"
    echo
    
    # Vérifier les arguments
    case "${1:-}" in
        --auto|-a)
            # Rollback automatique vers la dernière sauvegarde
            rollback_automatic
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo "Options:"
            echo "  (sans argument)  Mode interactif - liste et sélection de sauvegarde"
            echo "  -a, --auto       Rollback automatique vers la dernière sauvegarde"
            echo "  -h, --help       Afficher cette aide"
            echo ""
            echo "Variables d'environnement:"
            echo "  BACKUP_DIR       Répertoire des sauvegardes (défaut: $BACKUP_DIR)"
            echo "  DEPLOY_DIR       Répertoire de déploiement (défaut: $DEPLOY_DIR)"
            exit 0
            ;;
        "")
            # Mode interactif par défaut
            interactive_rollback
            ;;
        *)
            echo "Option inconnue: $1"
            echo "Utilisez '$0 --help' pour voir les options disponibles."
            exit 1
            ;;
    esac
}

# Gestion des signaux pour arrêt propre
trap 'error "Rollback interrompu par un signal."' INT TERM

# Exécution du script principal
main "$@"