#!/bin/bash

# ==============================================================================
# Script de Test d'Intégration - Git Integration
# ==============================================================================
# Description: Script pour valider l'intégration et les fonctionnalités
# Auteur: Système automatisé
# Date: 2025-12-07
# Version: 1.0
# ==============================================================================

set -euo pipefail  # Exit on error, undefined variables, pipe failures

# Configuration des couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Variables de configuration
PROJECT_NAME="git-integration"
APP_URL="${APP_URL:-http://localhost:3000}"
LOG_FILE="/var/log/git-integration-test.log"
TEST_RESULTS_DIR="/tmp/git-integration-tests"
SERVICE_NAME="git-integration"

# Compteurs pour les résultats de tests
TESTS_TOTAL=0
TESTS_PASSED=0
TESTS_FAILED=0

# Fonctions utilitaires
log() {
    local message="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${BLUE}[${timestamp}]${NC} $message" | tee -a "$LOG_FILE"
}

test_start() {
    local test_name="$1"
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
    echo -e "${CYAN}[TEST $TESTS_TOTAL]${NC} $test_name"
    log "Début du test: $test_name"
}

test_pass() {
    local message="$1"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    echo -e "${GREEN}✓ PASS${NC} $message"
    log "TEST PASSÉ: $message"
}

test_fail() {
    local message="$1"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    echo -e "${RED}✗ FAIL${NC} $message"
    log "TEST ÉCHOUÉ: $message"
}

test_skip() {
    local message="$1"
    echo -e "${YELLOW}⊘ SKIP${NC} $message"
    log "TEST Sauté: $message"
}

summary() {
    echo
    echo -e "${BLUE}=================================================================${NC}"
    echo -e "${BLUE}                    Résumé des Tests${NC}"
    echo -e "${BLUE}=================================================================${NC}"
    echo -e "Total des tests: $TESTS_TOTAL"
    echo -e "Réussis: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Échoués: ${RED}$TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}Tous les tests sont passés avec succès!${NC}"
        return 0
    else
        echo -e "${RED}Certains tests ont échoué. Vérifiez les logs pour plus de détails.${NC}"
        return 1
    fi
}

# Vérification des prérequis système
test_system_prerequisites() {
    test_start "Vérification des prérequis système"
    
    # Vérifier les outils requis
    local required_tools=("curl" "docker" "docker-compose" "jq")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [[ ${#missing_tools[@]} -eq 0 ]]; then
        test_pass "Tous les outils requis sont disponibles"
    else
        test_fail "Outils manquants: ${missing_tools[*]}"
    fi
    
    # Vérifier la mémoire disponible
    local available_memory=$(free -m | awk 'NR==2{printf "%.0f", $7}')
    if [[ $available_memory -gt 512 ]]; then
        test_pass "Mémoire disponible suffisante: ${available_memory}MB"
    else
        test_fail "Mémoire insuffisante: ${available_memory}MB (minimum: 512MB)"
    fi
}

# Test de connectivité des conteneurs
test_container_connectivity() {
    test_start "Connectivité des conteneurs Docker"
    
    # Vérifier si Docker est en cours d'exécution
    if ! docker info &> /dev/null; then
        test_fail "Docker n'est pas en cours d'exécution"
        return
    fi
    
    # Vérifier les conteneurs git-integration
    local containers=$(docker ps --filter "name=git-integration" --format "{{.Names}}" | wc -l)
    if [[ $containers -gt 0 ]]; then
        test_pass "$containers conteneur(s) git-integration en cours d'exécution"
        
        # Tester la connectivité réseau
        for container in $(docker ps --filter "name=git-integration" --format "{{.Names}}"); do
            if docker exec "$container" ping -c 1 8.8.8.8 &> /dev/null; then
                test_pass "Connectivité réseau du conteneur $container"
            else
                test_fail "Pas de connectivité réseau pour le conteneur $container"
            fi
        done
    else
        test_fail "Aucun conteneur git-integration trouvé"
    fi
}

# Test de l'API principale
test_api_health() {
    test_start "Health Check de l'API"
    
    # Test endpoint de santé
    if curl -sf "$APP_URL/health" &> /dev/null; then
        test_pass "Endpoint /health accessible"
        
        # Vérifier la structure de la réponse
        local health_response=$(curl -sf "$APP_URL/health")
        if echo "$health_response" | jq -e '.status' &> /dev/null; then
            local status=$(echo "$health_response" | jq -r '.status')
            test_pass "Réponse health avec statut: $status"
        else
            test_fail "Réponse health invalide ou mal formatée"
        fi
    else
        test_fail "Endpoint /health non accessible"
    fi
}

# Test des endpoints Git
test_git_endpoints() {
    test_start "Test des endpoints Git"
    
    local git_endpoints=(
        "/api/repositories"
        "/api/branches"
        "/api/commits"
    )
    
    for endpoint in "${git_endpoints[@]}"; do
        if curl -sf "$APP_URL$endpoint" &> /dev/null; then
            test_pass "Endpoint $endpoint accessible"
        else
            test_skip "Endpoint $endpoint non accessible (peut nécessiter une configuration)"
        fi
    done
}

# Test de performance basique
test_performance() {
    test_start "Test de performance basique"
    
    # Test de temps de réponse
    local response_time=$(curl -w "%{time_total}" -o /dev/null -s "$APP_URL/health")
    local response_time_ms=$(echo "$response_time * 1000" | bc | cut -d. -f1)
    
    if [[ $response_time_ms -lt 2000 ]]; then
        test_pass "Temps de réponse acceptable: ${response_time_ms}ms"
    else
        test_fail "Temps de réponse trop élevé: ${response_time_ms}ms"
    fi
    
    # Test de charge basique (10 requêtes simultanées)
    local concurrent_test=$(yes | head -10 | xargs -I {} -P 10 curl -s -w "%{time_total}" -o /dev/null "$APP_URL/health" | awk '{sum+=$1} END {print sum/NR}')
    local avg_response_time=$(echo "$concurrent_test * 1000" | bc | cut -d. -f1)
    
    if [[ $avg_response_time -lt 5000 ]]; then
        test_pass "Performance sous charge acceptable: ${avg_response_time}ms (moyenne)"
    else
        test_fail "Performance dégradée sous charge: ${avg_response_time}ms"
    fi
}

# Test des logs et monitoring
test_logs_monitoring() {
    test_start "Logs et monitoring"
    
    # Vérifier les logs Docker
    local log_errors=$(docker logs git-integration-app 2>&1 | grep -i "error\|exception\|failed" | wc -l)
    if [[ $log_errors -eq 0 ]]; then
        test_pass "Aucun erreur critique dans les logs"
    else
        test_fail "$log_errors erreur(s) trouvée(s) dans les logs"
    fi
    
    # Vérifier l'espace disque
    local disk_usage=$(df /opt | awk 'NR==2 {print $5}' | sed 's/%//')
    if [[ $disk_usage -lt 90 ]]; then
        test_pass "Utilisation disque acceptable: ${disk_usage}%"
    else
        test_fail "Espace disque critique: ${disk_usage}%"
    fi
}

# Test de sécurité basique
test_security_basics() {
    test_start "Tests de sécurité basiques"
    
    # Test de headers de sécurité
    local security_headers=("X-Content-Type-Options" "X-Frame-Options" "X-XSS-Protection")
    
    for header in "${security_headers[@]}"; do
        if curl -s -I "$APP_URL/health" | grep -qi "$header"; then
            test_pass "Header de sécurité présent: $header"
        else
            test_skip "Header de sécurité manquant: $header (optionnel)"
        fi
    done
    
    # Test de ports non autorisés
    local open_ports=$(netstat -tuln 2>/dev/null | grep -E ":(3000|8000|8080)" | wc -l)
    if [[ $open_ports -eq 1 ]]; then
        test_pass "Seuls les ports nécessaires sont ouverts"
    else
        test_fail "Configuration de ports inhabituelle détectée"
    fi
}

# Test d'intégration des fonctionnalités Git
test_git_integration() {
    test_start "Intégration des fonctionnalités Git"
    
    # Simuler un test d'intégration Git basique
    local test_repo="/tmp/test-git-repo"
    
    # Créer un repo de test
    mkdir -p "$test_repo"
    cd "$test_repo"
    git init -q
    
    # Test de commit
    echo "test content" > test.txt
    git add test.txt
    git commit -m "Test commit" -q
    
    if [[ $? -eq 0 ]]; then
        test_pass "Fonctionnalités Git de base opérationnelles"
    else
        test_fail "Échec des opérations Git de base"
    fi
    
    # Nettoyer
    cd /
    rm -rf "$test_repo"
}

# Test de sauvegarde et restauration
test_backup_restore() {
    test_start "Test de sauvegarde et restauration"
    
    # Vérifier le répertoire de sauvegarde
    local backup_dir="/opt/backups/git-integration"
    if [[ -d "$backup_dir" ]]; then
        local backup_count=$(find "$backup_dir" -name "backup-*.tar.gz" 2>/dev/null | wc -l)
        if [[ $backup_count -gt 0 ]]; then
            test_pass "Sauvegardes disponibles: $backup_count"
        else
            test_skip "Aucune sauvegarde trouvée"
        fi
    else
        test_skip "Répertoire de sauvegarde non configuré"
    fi
}

# Fonction principale
main() {
    local script_name=$(basename "$0")
    
    # Créer le répertoire de résultats
    mkdir -p "$TEST_RESULTS_DIR"
    
    # Affichage de l'en-tête
    echo -e "${BLUE}=================================================================${NC}"
    echo -e "${BLUE}          Script de Test d'Intégration - Git Integration${NC}"
    echo -e "${BLUE}=================================================================${NC}"
    echo -e "URL de l'application: ${CYAN}$APP_URL${NC}"
    echo -e "Fichier de log: ${CYAN}$LOG_FILE${NC}"
    echo
    
    # Exécution des tests
    {
        log "Début des tests d'intégration"
        
        test_system_prerequisites
        test_container_connectivity
        test_api_health
        test_git_endpoints
        test_performance
        test_logs_monitoring
        test_security_basics
        test_git_integration
        test_backup_restore
        
        summary
        
    } > "$TEST_RESULTS_DIR/test-results-$(date +%Y%m%d-%H%M%S).txt" 2>&1
    
    # Affichage du résumé à la fin
    summary
}

# Gestion des signaux
trap 'echo -e "\n${RED}Tests interrompus par un signal.${NC}"; exit 130' INT TERM

# Affichage de l'aide
show_help() {
    echo "Usage: $0 [OPTIONS]"
    echo "Options:"
    echo "  -u URL          URL de l'application (défaut: http://localhost:3000)"
    echo "  -h              Afficher cette aide"
    echo ""
    echo "Variables d'environnement:"
    echo "  APP_URL         URL de l'application (défaut: http://localhost:3000)"
    exit 0
}

# Parsing des arguments
while getopts ":u:h" opt; do
    case $opt in
        u)
            APP_URL="$OPTARG"
            ;;
        h)
            show_help
            ;;
        \?)
            echo "Option invalide: -$OPTARG" >&2
            exit 1
            ;;
    esac
done

# Exécution du script principal
main "$@"