#!/bin/bash

# ==============================================================================
# Script d'Initialisation Environnement - Git Integration
# ==============================================================================
# Description: Script pour initialiser et configurer l'environnement système
# Auteur: Système automatisé
# Date: 2025-12-07
# Version: 1.0
# ==============================================================================

set -euo pipefail  # Exit on error, undefined variables, pipe failures

# Configuration des couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Charger la configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/config.env"

# Variables de configuration
INIT_LOG="/var/log/git-integration-init.log"
REQUIRED_TOOLS=("git" "docker" "docker-compose" "curl" "jq" "bc" "tar" "netstat")
OPTIONAL_TOOLS=("python3" "node" "npm" "yarn" "helm" "kubectl")
MIN_DOCKER_VERSION="20.10"
MIN_DISK_SPACE_GB=5
MIN_MEMORY_GB=2

# Fonctions utilitaires
log() {
    local message="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${BLUE}[${timestamp}]${NC} $message" | tee -a "$INIT_LOG"
}

success() {
    local message="$1"
    echo -e "${GREEN}✅ $message${NC}" | tee -a "$INIT_LOG"
}

warning() {
    local message="$1"
    echo -e "${YELLOW}⚠️  $message${NC}" | tee -a "$INIT_LOG"
}

error() {
    local message="$1"
    echo -e "${RED}❌ $message${NC}" | tee -a "$INIT_LOG"
    exit 1
}

info() {
    local message="$1"
    echo -e "${CYAN}ℹ️  $message${NC}" | tee -a "$INIT_LOG"
}

# Vérification de la version d'un outil
check_version() {
    local tool="$1"
    local min_version="$2"
    local version_cmd="$3"
    
    local current_version
    current_version=$($version_cmd 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+' | head -n1)
    
    if [[ -z "$current_version" ]]; then
        return 1
    fi
    
    # Comparaison de version simple (pour les versions majeures mineures)
    IFS='.' read -ra CURRENT <<< "$current_version"
    IFS='.' read -ra MIN <<< "$min_version"
    
    if [[ ${CURRENT[0]} -gt ${MIN[0]} ]] || 
       ([[ ${CURRENT[0]} -eq ${MIN[0]} ]] && [[ ${CURRENT[1]} -ge ${MIN[1]} ]]); then
        return 0
    else
        return 1
    fi
}

# Vérification des outils requis
check_required_tools() {
    log "Vérification des outils requis..."
    
    local missing_tools=()
    local version_issues=()
    
    for tool in "${REQUIRED_TOOLS[@]}"; do
        if command -v "$tool" &> /dev/null; then
            success "Outil requis disponible: $tool"
            
            # Vérifications de version spécifiques
            case "$tool" in
                "docker")
                    if ! check_version "$tool" "$MIN_DOCKER_VERSION" "docker --version"; then
                        version_issues+=("Docker version >= $MIN_DOCKER_VERSION requis (actuel: $(docker --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+'))")
                    fi
                    ;;
            esac
        else
            missing_tools+=("$tool")
        fi
    done
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        error "Outils requis manquants: ${missing_tools[*]}"
        echo
        echo "Pour installer les outils manquants:"
        echo "  Ubuntu/Debian: sudo apt update && sudo apt install -y ${missing_tools[*]}"
        echo "  CentOS/RHEL: sudo yum install -y ${missing_tools[*]}"
        echo "  ou utilisez le script d'installation automatique avec --install-deps"
        exit 1
    fi
    
    if [[ ${#version_issues[@]} -gt 0 ]]; then
        error "Problèmes de version détectés:"
        for issue in "${version_issues[@]}"; do
            echo "  - $issue"
        done
        exit 1
    fi
    
    success "Tous les outils requis sont installés avec les bonnes versions."
}

# Vérification des outils optionnels
check_optional_tools() {
    log "Vérification des outils optionnels..."
    
    local available_optional=()
    local missing_optional=()
    
    for tool in "${OPTIONAL_TOOLS[@]}"; do
        if command -v "$tool" &> /dev/null; then
            available_optional+=("$tool")
        else
            missing_optional+=("$tool")
        fi
    done
    
    if [[ ${#available_optional[@]} -gt 0 ]]; then
        success "Outils optionnels disponibles: ${available_optional[*]}"
    fi
    
    if [[ ${#missing_optional[@]} -gt 0 ]]; then
        warning "Outils optionnels manquants: ${missing_optional[*]} (recommandés pour le développement)"
    fi
}

# Vérification des ressources système
check_system_resources() {
    log "Vérification des ressources système..."
    
    # Vérification de la mémoire
    local total_memory_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    local total_memory_gb=$((total_memory_kb / 1024 / 1024))
    
    if [[ $total_memory_gb -ge $MIN_MEMORY_GB ]]; then
        success "Mémoire disponible: ${total_memory_gb}GB (minimum: ${MIN_MEMORY_GB}GB)"
    else
        warning "Mémoire insuffisante: ${total_memory_gb}GB (recommandé: ${MIN_MEMORY_GB}GB minimum)"
    fi
    
    # Vérification de l'espace disque
    local available_space_kb=$(df /opt | awk 'NR==2 {print $4}')
    local available_space_gb=$((available_space_kb / 1024 / 1024))
    
    if [[ $available_space_gb -ge $MIN_DISK_SPACE_GB ]]; then
        success "Espace disque disponible: ${available_space_gb}GB (minimum: ${MIN_DISK_SPACE_GB}GB)"
    else
        error "Espace disque insuffisant: ${available_space_gb}GB (minimum requis: ${MIN_DISK_SPACE_GB}GB)"
    fi
    
    # Vérification de l'espace pour les logs
    local log_space_kb=$(df /var/log | awk 'NR==2 {print $4}')
    local log_space_gb=$((log_space_kb / 1024 / 1024))
    
    if [[ $log_space_gb -ge 1 ]]; then
        success "Espace pour les logs: ${log_space_gb}GB"
    else
        warning "Espace limité pour les logs: ${log_space_gb}GB"
    fi
}

# Vérification de l'environnement Docker
check_docker_environment() {
    log "Vérification de l'environnement Docker..."
    
    # Vérifier si Docker est en cours d'exécution
    if ! docker info &> /dev/null; then
        error "Docker n'est pas en cours d'exécution. Démarrez Docker et réessayez."
    fi
    
    success "Docker est en cours d'exécution."
    
    # Vérifier les permissions Docker
    if ! docker ps &> /dev/null; then
        warning "Permissions Docker insuffisantes. Ajout de l'utilisateur au groupe docker..."
        sudo usermod -aG docker "$(whoami)"
        warning "Vous devez vous déconnecter et vous reconnecter pour que les modifications prennent effet."
    else
        success "Permissions Docker correctes."
    fi
    
    # Vérifier l'espace de stockage Docker
    local docker_space=$(docker system df --format "{{.Size}}" | tail -n 1)
    if [[ -n "$docker_space" ]]; then
        info "Espace utilisé par Docker: $docker_space"
    fi
}

# Création des répertoires nécessaires
setup_directories() {
    log "Configuration des répertoires..."
    
    local directories=(
        "$DEPLOY_DIR"
        "$BACKUP_DIR"
        "$LOG_DIR"
        "$CONFIG_DIR"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            sudo mkdir -p "$dir"
            sudo chown "$(whoami):$(whoami)" "$dir" 2>/dev/null || true
            success "Répertoire créé: $dir"
        else
            info "Répertoire existant: $dir"
        fi
    done
    
    # Créer le fichier de configuration par défaut
    local config_file="$CONFIG_DIR/config.env"
    if [[ ! -f "$config_file" ]]; then
        sudo cp "$SCRIPT_DIR/config.env" "$config_file"
        sudo chown "$(whoami):$(whoami)" "$config_file" 2>/dev/null || true
        success "Fichier de configuration créé: $config_file"
        warning "Modifiez ce fichier avec vos paramètres spécifiques avant le déploiement."
    fi
}

# Configuration des permissions
setup_permissions() {
    log "Configuration des permissions..."
    
    # Permissions pour les répertoires de travail
    chmod 755 "$DEPLOY_DIR" 2>/dev/null || true
    chmod 755 "$BACKUP_DIR" 2>/dev/null || true
    chmod 755 "$LOG_DIR" 2>/dev/null || true
    
    success "Permissions configurées."
}

# Test de connectivité réseau
test_network_connectivity() {
    log "Test de connectivité réseau..."
    
    local test_urls=(
        "https://hub.docker.com"
        "https://github.com"
        "8.8.8.8"
    )
    
    local failed_tests=()
    
    for url in "${test_urls[@]}"; do
        if curl -f -s --max-time 10 "$url" &> /dev/null || ping -c 1 "$url" &> /dev/null; then
            success "Connectivité OK: $url"
        else
            failed_tests+=("$url")
        fi
    done
    
    if [[ ${#failed_tests[@]} -gt 0 ]]; then
        warning "Tests de connectivité échoués pour: ${failed_tests[*]}"
        warning "Vérifiez votre connexion Internet et les pare-feu."
    else
        success "Tous les tests de connectivité réussis."
    fi
}

# Génération du rapport de système
generate_system_report() {
    log "Génération du rapport système..."
    
    local report_file="/tmp/git-integration-system-report-$(date +%Y%m%d-%H%M%S).txt"
    
    {
        echo "==================================================================="
        echo "          RAPPORT D'INITIALISATION - Git Integration"
        echo "==================================================================="
        echo "Date: $(date)"
        echo "Utilisateur: $(whoami)"
        echo "Hôte: $(hostname)"
        echo
        
        echo "=== INFORMATIONS SYSTÈME ==="
        echo "OS: $(lsb_release -d 2>/dev/null | cut -f2 || uname -s)"
        echo "Kernel: $(uname -r)"
        echo "Architecture: $(uname -m)"
        echo
        
        echo "=== RESSOURCES SYSTÈME ==="
        echo "Mémoire totale: $(free -h | grep '^Mem:' | awk '{print $2}')"
        echo "Mémoire disponible: $(free -h | grep '^Mem:' | awk '{print $7}')"
        echo "Espace disque /opt: $(df -h /opt | tail -1 | awk '{print $4}') libre sur $(df -h /opt | tail -1 | awk '{print $2}')"
        echo "Espace disque /var/log: $(df -h /var/log | tail -1 | awk '{print $4}') libre"
        echo

        echo "=== OUTILS INSTALLÉS ==="
        for tool in "${REQUIRED_TOOLS[@]}" "${OPTIONAL_TOOLS[@]}"; do
            if command -v "$tool" &> /dev/null; then
                local version="$($tool --version 2>/dev/null | head -n1 || echo "Version non disponible")"
                echo "$tool: $version"
            else
                echo "$tool: NON INSTALLÉ"
            fi
        done
        echo

        echo "=== DOCKER ==="
        echo "Version: $(docker --version)"
        echo "Statut: $(docker info 2>/dev/null >/dev/null && 'En cours d\'exécution' || 'Arrêté')"
        echo

        echo "=== RÉPERTOIRES ==="
        echo "DEPLOY_DIR: $DEPLOY_DIR"
        echo "BACKUP_DIR: $BACKUP_DIR"
        echo "LOG_DIR: $LOG_DIR"
        echo "CONFIG_DIR: $CONFIG_DIR"
        echo

        echo "=== CONFIGURATION ==="
        echo "PROJECT_NAME: $PROJECT_NAME"
        echo "APP_URL: $APP_URL"
        echo "REPO_URL: $REPO_URL"
        echo "NODE_ENV: $NODE_ENV"
        echo

    } > "$report_file"
    
    success "Rapport système généré: $report_file"
    cat "$report_file"
}

# Installation automatique des dépendances
install_dependencies() {
    log "Installation automatique des dépendances..."
    
    if [[ $EUID -eq 0 ]]; then
        error "Ce script ne doit pas être exécuté en tant que root pour l'installation."
    fi
    
    # Détecter le gestionnaire de paquets
    local pkg_manager=""
    if command -v apt &> /dev/null; then
        pkg_manager="apt"
    elif command -v yum &> /dev/null; then
        pkg_manager="yum"
    elif command -v dnf &> /dev/null; then
        pkg_manager="dnf"
    else
        error "Gestionnaire de paquets non supporté. Installez manuellement: ${REQUIRED_TOOLS[*]}"
    fi
    
    info "Gestionnaire de paquets détecté: $pkg_manager"
    
    # Mise à jour et installation
    case "$pkg_manager" in
        "apt")
            sudo apt update
            sudo apt install -y "${REQUIRED_TOOLS[@]}"
            ;;
        "yum")
            sudo yum install -y "${REQUIRED_TOOLS[@]}"
            ;;
        "dnf")
            sudo dnf install -y "${REQUIRED_TOOLS[@]}"
            ;;
    esac
    
    success "Dépendances installées avec succès."
}

# Fonction principale
main() {
    local script_name=$(basename "$0")
    
    # Affichage de l'en-tête
    echo -e "${CYAN}=================================================================${NC}"
    echo -e "${CYAN}        Initialisation Environnement - Git Integration${NC}"
    echo -e "${CYAN}=================================================================${NC}"
    echo
    
    # Parsing des arguments
    local install_deps=false
    local generate_report=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --install-deps)
                install_deps=true
                shift
                ;;
            --report)
                generate_report=true
                shift
                ;;
            --help|-h)
                echo "Usage: $0 [OPTIONS]"
                echo "Options:"
                echo "  --install-deps    Installer automatiquement les dépendances"
                echo "  --report          Générer un rapport système détaillé"
                echo "  --help, -h        Afficher cette aide"
                exit 0
                ;;
            *)
                error "Option inconnue: $1"
                ;;
        esac
    done
    
    # Exécution des vérifications
    {
        if [[ "$install_deps" == "true" ]]; then
            install_dependencies
            echo
        fi
        
        check_required_tools
        check_optional_tools
        check_system_resources
        check_docker_environment
        setup_directories
        setup_permissions
        test_network_connectivity
        
        if [[ "$generate_report" == "true" ]]; then
            echo
            generate_system_report
        fi
        
        success "Initialisation terminée avec succès!"
        echo
        echo -e "${GREEN}Prochaines étapes:${NC}"
        echo "1. Modifiez la configuration dans $CONFIG_DIR/config.env"
        echo "2. Exécutez le déploiement: ./deploy-integration.sh"
        echo "3. Testez l'installation: ./test-integration.sh"
        
    } || {
        error "Échec de l'initialisation. Consultez le log: $INIT_LOG"
    }
}

# Gestion des signaux
trap 'echo -e "\n${RED}Initialisation interrompue par un signal.${NC}"; exit 130' INT TERM

# Exécution du script principal
main "$@"