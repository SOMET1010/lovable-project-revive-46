#!/bin/bash

# ==============================================================================
# Guide de Démarrage Rapide - Git Integration
# ==============================================================================
# Description: Script interactif pour guider l'utilisateur dans la première utilisation
# ==============================================================================

set -euo pipefail

# Configuration des couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}=================================================================${NC}"
echo -e "${CYAN}        Guide de Démarrage Rapide - Git Integration${NC}"
echo -e "${CYAN}=================================================================${NC}"
echo

# Menu principal
show_menu() {
    echo -e "${YELLOW}Que souhaitez-vous faire ?${NC}"
    echo
    echo "1) Initialiser l'environnement système"
    echo "2) Déployer l'application"
    echo "3) Tester l'application déployée"
    echo "4) Effectuer un rollback"
    echo "5) Voir la documentation complète"
    echo "6) Quitter"
    echo
}

# Fonction pour vérifier si les scripts existent
check_scripts() {
    local scripts=("init-environment.sh" "deploy-integration.sh" "test-integration.sh" "rollback.sh")
    
    for script in "${scripts[@]}"; do
        if [[ ! -f "$SCRIPT_DIR/$script" ]]; then
            echo -e "${RED}Erreur: Script manquant: $script${NC}"
            return 1
        fi
    done
    return 0
}

# Rendre les scripts exécutables
make_executable() {
    echo -e "${BLUE}Configuration des permissions...${NC}"
    chmod +x "$SCRIPT_DIR"/*.sh 2>/dev/null || {
        echo -e "${YELLOW}Attention: Impossible de modifier les permissions automatiquement.${NC}"
        echo -e "${YELLOW}Utilisez: chmod +x *.sh${NC}"
    }
}

# Fonction principale
main() {
    local SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    # Vérifier les scripts
    if ! check_scripts; then
        echo -e "${RED}Certains scripts sont manquants. Veuillez vérifier l'installation.${NC}"
        exit 1
    fi
    
    # Configuration des permissions
    make_executable
    
    while true; do
        show_menu
        read -p "Votre choix (1-6): " choice
        
        case $choice in
            1)
                echo -e "${BLUE}=== Initialisation de l'Environnement ===${NC}"
                echo "Cette étape vérifie et configure votre système."
                echo
                read -p "Continuer ? [Y/n]: " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
                    "$SCRIPT_DIR/init-environment.sh" --install-deps
                fi
                ;;
            2)
                echo -e "${BLUE}=== Déploiement de l'Application ===${NC}"
                echo "Cette étape déploie l'application Git Integration."
                echo
                read -p "Continuer ? [Y/n]: " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
                    "$SCRIPT_DIR/deploy-integration.sh"
                fi
                ;;
            3)
                echo -e "${BLUE}=== Test de l'Application ===${NC}"
                echo "Cette étape valide le bon fonctionnement de l'application."
                echo
                read -p "Continuer ? [Y/n]: " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
                    "$SCRIPT_DIR/test-integration.sh"
                fi
                ;;
            4)
                echo -e "${BLUE}=== Rollback ===${NC}"
                echo "Cette étape permet de revenir à une version précédente."
                echo -e "${RED}ATTENTION: Cette opération remplace la version actuelle.${NC}"
                echo
                read -p "Continuer ? [y/N]: " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    "$SCRIPT_DIR/rollback.sh"
                fi
                ;;
            5)
                echo -e "${BLUE}=== Documentation ===${NC}"
                echo
                if [[ -f "$SCRIPT_DIR/README.md" ]]; then
                    cat "$SCRIPT_DIR/README.md"
                else
                    echo "Fichier README.md non trouvé."
                fi
                ;;
            6)
                echo -e "${GREEN}Au revoir !${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Choix invalide. Veuillez sélectionner une option entre 1 et 6.${NC}"
                ;;
        esac
        
        echo
        read -p "Appuyez sur Entrée pour continuer..."
        echo
    done
}

main "$@"