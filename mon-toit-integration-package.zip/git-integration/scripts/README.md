# Scripts de Déploiement Automatisé - Git Integration

Ce répertoire contient les scripts automatisés pour le déploiement, les tests et la gestion des rollback de l'application Git Integration.

## 📋 Scripts Disponibles

### 1. `deploy-integration.sh` - Déploiement Automatisé

Script principal pour déployer l'application d'intégration Git avec gestion des erreurs et sauvegardes automatiques.

#### Fonctionnalités
- ✅ Vérification des prérequis système
- ✅ Création automatique de sauvegardes
- ✅ Mise à jour du code source via Git
- ✅ Construction et déploiement des conteneurs Docker
- ✅ Vérification de l'état du déploiement
- ✅ Nettoyage automatique des ressources

#### Utilisation
```bash
# Déploiement avec les paramètres par défaut
./deploy-integration.sh

# Déploiement avec un repository spécifique
./deploy-integration.sh -r https://github.com/username/git-integration.git

# Afficher l'aide
./deploy-integration.sh -h
```

#### Variables d'Environnement
- `REPO_URL` : URL du repository Git (optionnel)
- `DEPLOY_DIR` : Répertoire de déploiement (défaut: `/opt/git-integration`)
- `BACKUP_DIR` : Répertoire des sauvegardes (défaut: `/opt/backups/git-integration`)

#### Prérequis
- Utilisateur avec privilèges sudo (mais pas root)
- Git, Docker, Docker Compose installés
- Au moins 2GB d'espace disque libre
- Ports 3000 disponibles

### 2. `test-integration.sh` - Tests d'Intégration

Script complet de validation pour vérifier l'état et le bon fonctionnement de l'application déployée.

#### Fonctionnalités
- 🔍 Tests de prérequis système
- 🐳 Vérification de la connectivité des conteneurs
- 🌐 Tests des endpoints API (health, git endpoints)
- ⚡ Tests de performance basique
- 📊 Analyse des logs et monitoring
- 🔒 Tests de sécurité basique
- 🔧 Validation des fonctionnalités Git
- 💾 Tests de sauvegarde/restauration

#### Utilisation
```bash
# Tests avec les paramètres par défaut (localhost:3000)
./test-integration.sh

# Tests avec une URL personnalisée
./test-integration.sh -u http://production.example.com:3000

# Afficher l'aide
./test-integration.sh -h
```

#### Variables d'Environnement
- `APP_URL` : URL de l'application à tester (défaut: `http://localhost:3000`)

#### Tests Inclus
1. **Prérequis Système** : Vérification des outils et ressources
2. **Connectivité Docker** : État des conteneurs et réseau
3. **API Health** : Endpoints de santé et structure de réponse
4. **Endpoints Git** : Fonctionnalités d'intégration Git
5. **Performance** : Temps de réponse et charge
6. **Logs & Monitoring** : Analyse des erreurs et ressources
7. **Sécurité** : Headers de sécurité et ports
8. **Intégration Git** : Opérations Git de base
9. **Sauvegarde** : Validation des backups

#### Résultats
- Résumé détaillé affiché à la fin
- Fichiers de résultats sauvegardés dans `/tmp/git-integration-tests/`
- Logs complets dans `/var/log/git-integration-test.log`

### 3. `rollback.sh` - Retour en Arrière

Script sécurisé pour restaurer une version précédente de l'application en cas de problème.

#### Fonctionnalités
- 🔄 Mode interactif et automatique
- 📋 Liste des sauvegardes disponibles
- 💾 Sauvegarde de l'état actuel avant rollback
- 🛑 Arrêt propre des services
- ⬅️ Restauration depuis sauvegarde
- ✅ Vérification de l'état après rollback
- 🧹 Nettoyage automatique des anciennes sauvegardes

#### Utilisation

**Mode Interactif (par défaut)**
```bash
./rollback.sh
# Liste les sauvegardes et demande de sélection
```

**Mode Automatique**
```bash
./rollback.sh --auto
# Restaure automatiquement la dernière sauvegarde
```

**Aide**
```bash
./rollback.sh --help
```

#### Fonctionnalités de Sécurité
- Confirmation utilisateur obligatoire (mode interactif)
- Sauvegarde de l'état actuel avant rollback
- Vérification de l'état après restauration
- Limitation du nombre de sauvegardes conservées

#### Variables d'Environnement
- `BACKUP_DIR` : Répertoire des sauvegardes (défaut: `/opt/backups/git-integration`)
- `DEPLOY_DIR` : Répertoire de déploiement (défaut: `/opt/git-integration`)
- `MAX_BACKUPS_TO_KEEP` : Nombre max de sauvegardes à conserver (défaut: 10)

## 🛡️ Sécurité et Bonnes Pratiques

### Sécurité Implémentée
- **Pas d'exécution root** : Les scripts vérifient qu'ils ne sont pas exécutés en tant que root
- **Validation des prérequis** : Vérification systématique des outils requis
- **Gestion d'erreurs robuste** : Arrêt immédiat en cas d'erreur critique
- **Sauvegardes automatiques** : Protection des données avant toute opération
- **Logs détaillés** : Traçabilité complète de toutes les opérations

### Bonnes Pratiques
- **Tests avant production** : Toujours tester en environnement de staging
- **Surveillance des logs** : Consultation régulière des fichiers de log
- **Maintenance des sauvegardes** : Vérification périodique de l'intégrité des backups
- **Documentation des versions** : Tenir un journal des déploiements

## 📊 Structure des Fichiers

```
/workspace/git-integration/scripts/
├── deploy-integration.sh    # Script de déploiement principal
├── test-integration.sh      # Script de tests d'intégration
├── rollback.sh             # Script de retour en arrière
└── README.md               # Cette documentation
```

## 📝 Fichiers de Log

Tous les scripts génèrent des logs détaillés :

- **Déploiement** : `/var/log/git-integration-deploy.log`
- **Tests** : `/var/log/git-integration-test.log`
- **Rollback** : `/var/log/git-integration-rollback.log`

## 🔧 Configuration Système Requise

### Prérequis Logiciels
- **OS** : Linux (Ubuntu 18.04+, CentOS 7+)
- **Docker** : Version 20.10+
- **Docker Compose** : Version 2.0+
- **Git** : Version 2.0+
- **Outils réseau** : curl, netstat
- **bc** : Calculatrice en ligne de commande

### Prérequis Matériel
- **RAM** : Minimum 2GB
- **Espace disque** : Minimum 5GB libres
- **CPU** : 2 cores minimum
- **Réseau** : Accès Internet pour pull des images Docker

### Ports Utilisés
- **3000** : Application principale
- **8000** : API backend (si applicable)
- **8080** : Interface web (si applicable)

## 🚨 Dépannage

### Problèmes Courants

**Erreur "Permission denied"**
```bash
# Vérifier les permissions sudo
sudo usermod -aG docker $USER
newgrp docker
```

**Espace disque insuffisant**
```bash
# Nettoyer les anciennes images Docker
docker system prune -a
```

**Conteneurs qui ne démarrent pas**
```bash
# Vérifier les logs
docker logs git-integration-app
docker-compose logs
```

**Tests qui échouent**
```bash
# Vérifier la connectivité réseau
curl -v http://localhost:3000/health
```

### Récupération d'Urgence

Si l'application est complètement cassée :

1. **Rollback immédiat** :
   ```bash
   ./rollback.sh --auto
   ```

2. **Vérification de l'état** :
   ```bash
   ./test-integration.sh
   ```

3. **Diagnostic système** :
   ```bash
   # Vérifier les logs système
   sudo journalctl -u docker
   sudo dmesg | grep docker
   ```

## 📞 Support

Pour toute question ou problème :

1. Consulter les logs des scripts
2. Vérifier la documentation technique
3. Tester avec `./test-integration.sh` pour diagnostic
4. Utiliser `./rollback.sh --auto` en cas d'urgence

## 📝 Changelog

### Version 1.0 (2025-12-07)
- ✅ Création des scripts de déploiement automatisé
- ✅ Implémentation des tests d'intégration complets
- ✅ Script de rollback avec modes interactif et automatique
- ✅ Documentation complète et sécurisée
- ✅ Gestion d'erreurs robuste et logs détaillés

---

*Scripts générés automatiquement le 2025-12-07 pour le projet Git Integration*