# Documentation des Dépendances et Configuration - Mon Toit

## 📋 Vue d'ensemble

Ce document liste toutes les dépendances npm ajoutées pour l'intégration des cartes Mapbox avec clustering, ainsi que les configurations requises pour le bon fonctionnement de l'application.

## 🗺️ Nouvelles Dépendances Cartographie

### Dépendances Principales

```json
{
  "mapbox-gl": "^3.16.0",
  "supercluster": "^8.0.1",
  "@types/mapbox-gl": "^3.4.1",
  "@types/supercluster": "^7.1.3"
}
```

### Détails des Dépendances

#### mapbox-gl (v3.16.0)
- **Purpose**: Librairie principale pour les cartes interactives
- **Usage**: Affichage des cartes, marqueurs, popups, contrôles de navigation
- **CSS**: Requiert l'import de `'mapbox-gl/dist/mapbox-gl.css'`
- **Compatibility**: React 18+, TypeScript 5+

#### supercluster (v8.0.1)
- **Purpose**: Clustering performant pour les marqueurs de propriétés
- **Usage**: Regroupement automatique des propriétés proches sur la carte
- **Benefits**: Performance optimale avec de nombreuses propriétés
- **Type Safety**: Types TypeScript fournis

#### Types TypeScript
- `@types/mapbox-gl`: Types complets pour l'API Mapbox
- `@types/supercluster`: Types pour le clustering
- **Configuration**: Déjà inclus dans `tsconfig.app.json`

## 🔑 Variables d'Environnement Requises

### Configuration Mapbox

```bash
# Token d'accès public Mapbox (requis pour les cartes)
VITE_MAPBOX_PUBLIC_TOKEN=votre_token_mapbox_public

# Alternative (legacy)
VITE_MAPBOX_ACCESS_TOKEN=votre_token_mapbox_access
```

### Configuration Supabase (Edge Function)

Pour la gestion sécurisée des tokens, une Edge Function Supabase est utilisée:

```typescript
// Edge Function: get-mapbox-token
// Retourne le token depuis les secrets Supabase
// Usage: supabase.functions.invoke("get-mapbox-token")
```

### Configuration des Autres Services

```bash
# Supabase (requis pour la production)
VITE_SUPABASE_URL=https://votre-projet.supabase.co
VITE_SUPABASE_ANON_KEY=votre-cle-publique-supabase

# Azure (optionnel)
VITE_AZURE_SPEECH_KEY=votre-cle-azure-speech
VITE_AZURE_VISION_KEY=votre-cle-azure-vision

# Paiements Mobile Money (optionnel)
VITE_INTOUCH_USERNAME=your_intouch_username
VITE_INTOUCH_PASSWORD=your_intouch_password

# Communication (optionnel)
RESEND_API_KEY=your_resend_api_key
BREVO_API_KEY=your_brevo_api_key
```

## 📜 Scripts npm à Mettre à Jour

### Scripts Existants à Conserver

```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build --config vite.config.optimized.ts",
    "build:dev": "vite build",
    "build:standard": "vite build",
    "build:analyze": "vite build --config vite.config.optimized.ts && open stats.html",
    "lint": "eslint .",
    "lint:fix": "eslint . --fix",
    "format": "prettier --write \"src/**/*.{ts,tsx,js,jsx,json,css,md}\"",
    "format:check": "prettier --check \"src/**/*.{ts,tsx,js,jsx,json,css,md}\"",
    "preview": "vite preview",
    "typecheck": "tsc --noEmit -p tsconfig.app.json",
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest run --coverage"
  }
}
```

### Scripts Ajoutés pour les Tests de Performance

```json
{
  "scripts": {
    "test:memory": "vitest run tests/memory-leaks-validation.test.ts",
    "test:memory:watch": "vitest tests/memory-leaks-validation.test.ts --watch",
    "memory-check": "node check-memory-leaks.js",
    "memory-check:file": "node check-memory-leaks.js --file",
    "memory-audit": "npm run memory-check && npm run test:memory"
  }
}
```

## ⚙️ Configuration TypeScript Requise

### Configuration Principale (tsconfig.app.json)

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    
    /* Path Mapping */
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"],
      "@config": ["./src/config/index.ts"],
      "@config/*": ["./src/config/*"],
      "@components": ["./src/components/index.ts"],
      "@components/*": ["./src/components/*"],
      "@pages": ["./src/pages/index.ts"],
      "@pages/*": ["./src/pages/*"],
      "@services": ["./src/services/index.ts"],
      "@services/*": ["./src/services/*"],
      "@hooks": ["./src/hooks/index.ts"],
      "@hooks/*": ["./src/hooks/*"],
      "@lib": ["./src/lib/index.ts"],
      "@lib/*": ["./src/lib/*"],
      "@types": ["./src/types/index.ts"],
      "@types/*": ["./src/types/*"],
      "@contexts": ["./src/contexts/index.ts"],
      "@contexts/*": ["./src/contexts/*"],
      "@stores": ["./src/stores/index.ts"],
      "@stores/*": ["./src/stores/*"]
    },
    
    /* Bundler mode */
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "isolatedModules": true,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",
    
    /* Linting strict */
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitReturns": true,
    "noPropertyAccessFromIndexSignature": true,
    "forceConsistentCasingInFileNames": true,
    "exactOptionalPropertyTypes": false,
    "noImplicitOverride": true
  },
  "include": ["src"]
}
```

### Configuration Vite (vite.config.ts)

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { componentTagger } from "lovable-tagger";

export default defineConfig(({ mode }) => ({
  plugins: [
    react(),
    mode === 'development' && componentTagger(),
  ].filter(Boolean),
  server: {
    host: "::",
    port: 8080,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@config': path.resolve(__dirname, './src/config'),
      '@components': path.resolve(__dirname, './src/components'),
      '@pages': path.resolve(__dirname, './src/pages'),
      '@services': path.resolve(__dirname, './src/services'),
      '@hooks': path.resolve(__dirname, './src/hooks'),
      '@lib': path.resolve(__dirname, './src/lib'),
      '@types': path.resolve(__dirname, './src/types'),
      '@contexts': path.resolve(__dirname, './src/contexts'),
      '@stores': path.resolve(__dirname, './src/stores'),
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
    include: ['mapbox-gl'],
  },
}));
```

## 🏗️ Architecture des Composants

### Composant Principal: MapboxMap

```typescript
// src/shared/ui/MapboxMap.tsx
interface MapboxMapProps {
  center?: [number, number];
  zoom?: number;
  properties: Property[];
  highlightedPropertyId?: string;
  onMarkerClick?: (property: Property) => void;
  onBoundsChange?: (bounds: mapboxgl.LngLatBounds) => void;
  clustering?: boolean;
  draggableMarker?: boolean;
  showRadius?: boolean;
  radiusKm?: number;
  fitBounds?: boolean;
  height?: string;
  onMapClick?: (lngLat: { lng: number; lat: number }) => void;
  onMarkerDrag?: (lngLat: { lng: number; lat: number }) => void;
  searchEnabled?: boolean;
  singleMarker?: boolean;
}
```

### Hook de Gestion du Token

```typescript
// src/shared/hooks/useMapboxToken.ts
export function useMapboxToken() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["mapbox-token"],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("get-mapbox-token");
      if (error) throw error;
      return data.token as string;
    },
    staleTime: Infinity,
    gcTime: Infinity,
    retry: 2,
  });

  return { token: data, isLoading, error: error as Error | null };
}
```

### Configuration Centralisée

```typescript
// src/shared/config/api-keys.config.ts
readonly maps = {
  mapbox: {
    key: import.meta.env['VITE_MAPBOX_PUBLIC_TOKEN'] || '',
    endpoint: 'https://api.mapbox.com',
    isConfigured: !!import.meta.env['VITE_MAPBOX_PUBLIC_TOKEN'],
  } as MapConfig,
};
```

## 🔄 Notes de Compatibilité avec le Stack Existant

### Stack Technique Actuel

- **Frontend**: React 18.3.1 + TypeScript 5.5.3
- **Build Tool**: Vite 5.4.2
- **Styling**: Tailwind CSS 3.4.1
- **State Management**: Zustand 4.5.7
- **Database**: Supabase 2.86.0
- **UI Components**: Radix UI + shadcn/ui
- **Charts**: Recharts 3.5.1

### Compatibilité des Dépendances

#### ✅ Compatibilité Confirmée

- **React 18+**: mapbox-gl est compatible avec React 18
- **TypeScript 5+**: Types complets disponibles et intégrés
- **Vite 5+**: Configuration d'optimisation incluse
- **Tailwind CSS**: Styles personnalisés pour les marqueurs
- **Supabase**: Edge Functions pour la gestion sécurisée des tokens

#### ⚠️ Points d'Attention

1. **Performance**: 
   - Utiliser le clustering pour plus de 100 propriétés
   - Implémenter la virtualisation pour les grandes listes
   - Optimiser les re-renders avec `useMemo` et `useCallback`

2. **Bundle Size**:
   - mapbox-gl ajoute ~500KB au bundle
   - Configuration Vite pour l'optimisation incluse
   - Lazy loading des composants de carte recommandé

3. **SSR/SEO**:
   - Les cartes sont côté client uniquement
   - Fallback statique pour le SEO si nécessaire
   - Server-side rendering non supporté par mapbox-gl

### Migration depuis Google Maps

Si migration depuis `@react-google-maps/api`:

```typescript
// Avant (Google Maps)
import { GoogleMap, Marker, InfoWindow } from '@react-google-maps/api';

// Après (Mapbox)
import MapboxMap from '@/shared/ui/MapboxMap';
```

#### Changements d'API:

| Google Maps | Mapbox GL |
|-------------|-----------|
| `google.maps.Map` | `mapboxgl.Map` |
| `google.maps.Marker` | `mapboxgl.Marker` |
| `google.maps.InfoWindow` | `mapboxgl.Popup` |
| LatLng | [lng, lat] |
| Zoom level | Same |

### Sécurité et Bonnes Pratiques

#### Gestion des Tokens

```typescript
// ✅ Bon: Token depuis Edge Function
const { token } = useMapboxToken();

// ❌ Mauvais: Token directement dans le code
const token = 'pk.eyJ1Ijoi...'; // Ne jamais faire cela
```

#### Validation des Données

```typescript
// Validation des coordonnées
const validProperties = properties.filter(p => 
  typeof p.latitude === 'number' && 
  typeof p.longitude === 'number' &&
  p.latitude >= -90 && p.latitude <= 90 &&
  p.longitude >= -180 && p.longitude <= 180
);
```

#### Gestion d'Erreur

```typescript
// Fallback gracieux
if (!mapboxToken) {
  return (
    <div className="fallback-map">
      <MapPin className="h-8 w-8" />
      <span>Carte non disponible</span>
    </div>
  );
}
```

## 🚀 Instructions de Déploiement

### 1. Installation des Dépendances

```bash
npm install mapbox-gl@^3.16.0 supercluster@^8.0.1
npm install -D @types/mapbox-gl@^3.4.1 @types/supercluster@^7.1.3
```

### 2. Configuration des Variables d'Environnement

```bash
# Copier le fichier d'exemple
cp .env.example .env

# Configurer les tokens
VITE_MAPBOX_PUBLIC_TOKEN=pk.eyJ1IjoieW91ci11c2VybmFtZSIsImEiOiJjbHh..."
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 3. Configuration Supabase Edge Function

Créer l'Edge Function `get-mapbox-token`:

```typescript
// supabase/functions/get-mapbox-token/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const token = Deno.env.get('MAPBOX_ACCESS_TOKEN');
    
    if (!token) {
      throw new Error('Mapbox token not configured');
    }

    return new Response(
      JSON.stringify({ token }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
```

### 4. Build et Test

```bash
# Vérification TypeScript
npm run typecheck

# Build de production
npm run build

# Tests
npm run test
npm run test:memory
```

## 📊 Métriques et Monitoring

### Performance Targets

- **First Paint**: < 2s
- **Map Load**: < 1s (avec token caché)
- **Marker Rendering**: < 500ms pour 100 propriétés
- **Bundle Size**: +500KB (mapbox-gl)

### Monitoring Recommandé

```typescript
// Tracking de l'utilisation des cartes
import { trackEvent } from '@/lib/analytics';

const handleMapLoad = () => {
  trackEvent('map_loaded', {
    property_count: properties.length,
    clustering_enabled: clustering,
  });
};
```

## 🔧 Troubleshooting

### Problèmes Courants

1. **Token invalide**:
   ```
   Error: Mapbox token is invalid
   Solution: Vérifier VITE_MAPBOX_PUBLIC_TOKEN et Edge Function
   ```

2. **Propriétés sans coordonnées**:
   ```
   Warning: Some properties have missing coordinates
   Solution: Implémenter fallback avec coordonnées de ville
   ```

3. **Performance lente**:
   ```
   Warning: Too many markers without clustering
   Solution: Activer clustering pour >50 propriétés
   ```

### Debug Mode

```typescript
// Activer le debug Mapbox
if (import.meta.env.DEV) {
  mapboxgl.setRTLTextPlugin('https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-rtl-text/v0.2.3/mapbox-gl-rtl-text.js');
}
```

## 📚 Documentation Complémentaire

- [Mapbox GL JS API](https://docs.mapbox.com/mapbox-gl-js/api/)
- [Supercluster Documentation](https://github.com/mapbox/supercluster)
- [Integration Guide Complet](./INTEGRATION_GUIDE.md)
- [Rapport d'Intégration](./rapport_integration_mapbox_termine.md)

---

**Dernière mise à jour**: 7 décembre 2025  
**Version**: 1.0.0  
**Compatibilité**: Mon Toit v3.2.2+